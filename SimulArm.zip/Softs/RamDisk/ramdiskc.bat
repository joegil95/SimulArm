@echo Installer le logiciel Ramdisk Softperfect avant d'executer ce programme

Ramdiskc.exe /add:S /size:10M /fs:fat /label:SDcard

@echo Appuyer sur une touche pour detruire le RamDisk
Pause

Ramdiskc.exe /del:S /force

@echo Appuyer sur une touche pour terminer
Pause