/************************************************************************************
 *  
 * Test de la roue codeuse avec des leds
 *
 ************************************************************************************/

#include "stm32f4xx.h"
#include "stm32f4xx_gpio.h"
#include "stm32f4xx_rcc.h"

#include "lib_gpio.h"
#include "lib_timer.h"

/// Connecter la roue codeuse sur PD0 � PD3
/// Connecter des leds sur PE0 � PE7


void main()
	{
    uint16_t val= 0, v= 0;

	/// configuration des ports
    LibGPIO_Conf(GPIOD, GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3, GPIO_Mode_IN, GPIO_PuPd_UP, GPIO_Speed_2MHz);
    LibGPIO_Conf(GPIOE, GPIO_Pin_Low, GPIO_Mode_OUT, GPIO_OType_PP, GPIO_Speed_2MHz);

	while(True)
	  	{
		// attention !!!
		// tempo anti-rebond indispensable avec la roue codeuse !!!
		// car elle passe par des etats instables !!!

		//	val= ~GPIO_ReadInputData(GPIOD) & 0x0F00;

		do
		  	{
		  	val= ~GPIO_ReadInputData(GPIOD) & 0x000F;
			Lib_delay(10000);
			v= ~GPIO_ReadInputData(GPIOD) & 0x000F;
			}
		while (val != v);

		GPIO_Write(GPIOE, val);
		}
	}

