/************************************************************************************
 *  File:     main.c
 *  Purpose:  Cortex-M4 main file.
 ************************************************************************************/


#include "Lib_32f4.h"

#include "Lib_gpio.h"
#include "Lib_spi.h"
#include "Lib_dac.h"


/// Connecter l'afficheur LCD sur SPI1 pour DAC1 et SPI2 pour DAC2
/// La valeur affichee sur le LCD est la sortie DAC (0 � 3,300 Volts)

void main(void)
	{
	int x= 0;

	LibDAC_Init(DAC1);	   // Initialisation du DAC
   	

   	while(True)
   		{
		LibDAC_Output(DAC1, x);
		x+=10;

		Lib_delay(10000);
   		}

	}
