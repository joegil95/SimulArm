/**
 * UART Library for STM32F4 without interrupts
 */

#include <windows.h>

#include "Lib_32f4.h"

#ifndef LIBUART_H
#define LIBUART_H 250

extern USART_TypeDef * USART1;
extern USART_TypeDef * USART2;
extern USART_TypeDef * USART3;
extern USART_TypeDef * UART4;
extern USART_TypeDef * UART5;
extern USART_TypeDef * USART6;


#define USART_WordLength_8b       8
#define USART_WordLength_9b       9
                                    
#define USART_StopBits_1		ONESTOPBIT
#define USART_StopBits_2        TWOSTOPBITS
  
#define USART_Parity_No			NOPARITY
#define USART_Parity_Even		EVENPARITY
#define USART_Parity_Odd		ODDPARITY

#define USART_Mode_Rx           1
#define USART_Mode_Tx           2


void LibUart_Init(USART_TypeDef* USARTx, uint32_t baudrate, uint16_t datalen, uint16_t parity, uint16_t stops);

uint8_t LibUart_Getc(USART_TypeDef* USARTx);
void LibUart_Putc(USART_TypeDef* USARTx, char c);

uint8_t LibUart_Transmit_Ready(USART_TypeDef* USARTx);
uint8_t LibUart_Received_Data(USART_TypeDef* USARTx);


/**
 * Internal functions
 */

HANDLE OpenComPort(char * port, BYTE data, BYTE stop, BYTE parity, DWORD speed);
void SendComPort(HANDLE hPort, char * dat, unsigned n);
unsigned RecvComPort(HANDLE hPort, char * dat, unsigned n);
void FlushComPort(HANDLE hPort);

#endif
