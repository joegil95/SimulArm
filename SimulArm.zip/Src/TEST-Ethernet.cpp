/************************************************************************************
 *  File:     main.c
 *  Purpose:  Cortex-M4 main file.
 ************************************************************************************/


/// Connecter le cable Ethernet

#include <stdio.h>
#include <string.h>

#include "Lib_32f4.h"

#include "Lib_gpio.h"
#include "Lib_glcd.h"
#include "Lib_ethernet.h"

#include "Lib_tcpip.h"


// structures fournies

struct ADR_eth BROADCAST= {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
struct ADR_eth NUL_ETH= {0, 0, 0, 0, 0, 0};

struct ADR_eth local_eth= {0x??, 0x??, 0x??, 0x??, 0x??, 0x??};		// A adapter
struct ADR_eth host_eth= {0, 0, 0, 0, 0, 0};
struct ADR_ip local_ip= {?, ?, ?, ?};							// A adapter
struct ADR_ip host_ip= {0, 0, 0, 0};


int main(void)
    {
    uint32_t nb;
    struct TRAME_eth frame1, frame2;

    /// Ne marche plus si SystemInit() !!!
    /// SystemInit();

    GLCD_InitDisplay();
	GLCD_ClearScreen();
	GLCD_Move(LEFT, 0, 0);
    GLCD_Write("Init... ");

	LibGPIO_Conf(GPIOE, GPIO_Pin_Low, GPIO_Mode_OUT, GPIO_OType_PP, GPIO_Speed_2MHz);

    /// NB: l'initialisation demande environ 15 secondes
    if (LibEthernet_Init() == 0)
		GLCD_Write("OK");
	else 
		GLCD_Write("PB");

    /// configurer les adresses au prealable

    while(True)
        {
		// fabriquer la trame 1
		// ...
		// et l'emettre sur le reseau
		LibEthernet_Send(&frame1, size_frame1);
			
			
        // attente reponse reseau
        do
            {
            /// la librairie fonctionne en polling
            /// filtrage necessaire a cause des broadcasts

            nb= LibEthernet_Recv(&frame2);
            }
        while (nb == 0);

        // traiter la reponse dont la taille est nb
		// ...

        }

	LibEthernet_Close();
    return 0;
    }
