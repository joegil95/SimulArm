/**
 * Virtual LCD Library for STM32F4xx devices (4 bits mode)
 */

#include <string.h>

#ifndef LibLCD_H
#define LibLCD_H

#define LOW		0x0001
#define HIGH	0x0100

#define LCD_CMD_ERASE  	  0x10   // Commande d'effacement LCD
#define LCD_CMD_HOME  	  0x20   // Commande de renvoi du curseur � la position initiale	
#define LCD_CMD_NOBLK 	  0x40   // Commande d'arret du clignotement
#define LCD_CMD_BLINK 	  0x41   // Commande d'activation du clignotement

// Envoi au LCD du caract�re pass� en param�tre
void LCD_SendChar(char caractere);

// Envoi au LCD de la commande pass�e en param�tre
void LCD_SendCommand(char commande);

// Initialisation du LCD
void LCD_Init(GPIO_TypeDef * GPIOx, uint16_t Hilo);

// Effacement du LCD
void LCD_Erase(void);

// Renvoi du curseur en haut � gauche
void LCD_Home(void);

// Configuration clignotement
// 1 = actif - 0 = inactif
void LCD_Blink(int e);

// Ecriture d'une cha�ne de caract�re sur le LCD
// chaine : le pointeur sur la cha�ne de caract�res � envoyer
void LCD_Write(char *chaine);

// D�placement du curseur
// y : num�ro de la ligne (1 ou 2)
// x : num�ro du caract�re (1 � 16)
void LCD_MoveCursor(int y,int x);

// Affiche une variale de type entier sur l'�cran LCD
// entier : l'entier � afficher sur l'�cran
void LCD_ShowInt(int entier);

// Affiche une variable de type double � l'�cran avec un nombre de d�cimales d�fini
// vdouble : la valeur d�cimale � afficher
// nb_decimales : le nombre de d�cimales � afficher apr�s la virgule
void LCD_ShowDouble(double vdouble, int nb_decimales);

#endif

