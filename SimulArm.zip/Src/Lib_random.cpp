/**
 * @(#) JG, 2025
 */

#include "Lib_random.h"

void LibRandom_Init() 
	{
	srand(time(NULL));
	}

void LibRandom_DeInit() 
	{
	
	}

uint32_t LibRandom_Get() 
	{
	uint32_t r= 0;

	/// Attention car rand() retourne une valeur entre 0 et 32767, donc sur 15 bits !
	r= rand() << 17;		
	r+= rand() << 11;
	r+= rand();		// To be sure to get a 32 bit value

	return r;
	}
