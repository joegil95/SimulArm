/**
 * Copyright (C) JG 2020
 */

#include "Lib_32f4.h"

#include "Lib_clock.h"

#include "SimulArm.h"

extern Stm32F407 MyStm;


/**
  * @brief  Configure RTC peripheral
  * @param  clock = CLOCK_SOURCE_LSI (internal) or CLOCK_SOURCE_LSE (external)
  * @param  RTC_DateStructure = date structure for clock initilization
  * @param  RTC_TimeStructure = time structure for clock initilization
  * @param  flag = CLOCK_CHECK (get computer's clock) or CLOCK_FORCE (ignored)
  * @retval None
  */
void LibClock_Init(uint16_t clock, RTC_DateTypeDef * RTC_DateStruct, RTC_TimeTypeDef * RTC_TimeStruct, uint16_t flag)
    {
	if ((clock != CLOCK_SOURCE_LSE) && (clock != CLOCK_SOURCE_LSI)) return;

	// Only CLOCK_CHECK is allowed in simulation
    if ((flag == CLOCK_CHECK) && (MyStm.StRtc.Date.RTC_Date == 0))
        {
		RTC_SetDate(RTC_Format_BCD, RTC_DateStruct);
		RTC_SetTime(RTC_Format_BCD, RTC_TimeStruct);

		MyStm.StRtc.Date= *RTC_DateStruct;
		MyStm.StRtc.Time= *RTC_TimeStruct;

		// Enable RTC Clock
		MyStm.StRtc.Enabled= 1;
		}
    }


/**
  * @brief  Get current time.
  * @param  RTC_TimeStructure = time structure filled by function
  * @retval None
  */
void LibClock_GetTime(RTC_TimeTypeDef * RTC_TimeStruct)
    {
	if (! MyStm.StRtc.Enabled) return;

    // Get the current Time
	RTC_GetTime(RTC_Format_BCD, RTC_TimeStruct);
    }


/**
  * @brief  Set current time.
  * @param  RTC_TimeStructure = time structure passed to function
  * @retval None
  */
void LibClock_SetTime(RTC_TimeTypeDef * RTC_TimeStruct)
    {
	if (! MyStm.StRtc.Enabled) return;

	// Set the current Time
    RTC_SetTime(RTC_Format_BCD, RTC_TimeStruct);
    }


/**
  * @brief  Get current date.
  * @param  RTC_DateStructure = date structure filled by function
  * @retval None
  */
void LibClock_GetDate(RTC_DateTypeDef * RTC_DateStruct)
    {
	if (! MyStm.StRtc.Enabled) return;

    // Get the current Date
    RTC_GetDate(RTC_Format_BCD, RTC_DateStruct);
    }


/**
  * @brief  Set current date.
  * @param  RTC_DateStructure = date structure passed to function
  * @retval None
  */
void LibClock_SetDate(RTC_DateTypeDef * RTC_DateStruct)
    {
	if (! MyStm.StRtc.Enabled) return;

	// Set the current Date
	RTC_SetDate(RTC_Format_BCD, RTC_DateStruct);
    }


/**
  * @brief  Get current alarm time
  * @param  RTC_Alarm = RTC_Alarm_A or RTC_Alarm_B
  * @param  RTC_AlarmStructure = alarme structure filled by function
  * @retval None
  */
void LibClock_GetAlarm(uint32_t RTC_Alarm, RTC_AlarmTypeDef * RTC_AlarmStruct)
    {
	if (! MyStm.StRtc.Enabled) return;

	if (RTC_Alarm == RTC_Alarm_A)
		*RTC_AlarmStruct= MyStm.StRtc.AlarmA;
	if (RTC_Alarm == RTC_Alarm_B)
		*RTC_AlarmStruct= MyStm.StRtc.AlarmB;
    }


/**
  * @brief  Set current alarm time
  * @param  RTC_Alarm = RTC_Alarm_A or RTC_Alarm_B
  * @param  RTC_AlarmStructure = alarme structure passed to function or NULL to disable
  * @retval None
  */
void LibClock_SetAlarm(uint32_t RTC_Alarm, RTC_AlarmTypeDef * RTC_AlarmStruct)
    {
	if (! MyStm.StRtc.Enabled) return;

	if (RTC_AlarmStruct == NULL)
		{
		// Desactivation alarme
		RTC_AlarmCmd(RTC_Alarm, DISABLE);
		return;
		}

    // Pour pouvoir modifier une alarme il faut la desactiver
	RTC_AlarmCmd(RTC_Alarm, DISABLE);

	if (RTC_Alarm == RTC_Alarm_A)
		MyStm.StRtc.AlarmA= *RTC_AlarmStruct;
	if (RTC_Alarm == RTC_Alarm_B)
		MyStm.StRtc.AlarmB= *RTC_AlarmStruct;

    // Enable alarm
	RTC_AlarmCmd(RTC_Alarm, ENABLE);
    }


/**
  * @brief  Check if current alarm time is reached
  * @param  RTC_Alarm = RTC_Alarm_A or RTC_Alarm_B
  * @retval 0 or 1
  */
uint8_t LibClock_OnAlarm(uint32_t RTC_Alarm)
	{
	if (RTC_Alarm == RTC_Alarm_A)
		return MyStm.StRtc.AlarmAOn;
	if (RTC_Alarm == RTC_Alarm_B)
		return MyStm.StRtc.AlarmBOn;

	return 0;
	}


/**
  * @brief  Activate or deactivate alarm
  * @param  RTC_Alarm = RTC_Alarm_A or RTC_Alarm_B
  * @param  state= ENABLE or DISABLE
  * @retval None
  */
void LibClock_CmdAlarm(uint32_t RTC_Alarm, FunctionalState state)
    {
	if (! MyStm.StRtc.Enabled) return;

	RTC_AlarmCmd(RTC_Alarm, state);
    }


/**
 * @brief  Convert values from decimal to BCD format
 * @param  c = decimal value to convert
 * @retval Converted BCD value
 */
uint8_t DecToBcd(uint8_t c)
	{
	uint8_t bcd;

	bcd= ((c/10) << 4) + (c%10);
	return bcd;
	}

/**
 * @brief  Convert values from BCD to decimal format
 * @param  c = BCD value to convert
 * @retval Converted decimal value
 */
uint8_t BcdToDec(uint8_t c)
    {
	uint8_t dec;

	dec= 10*(c >> 4) + (c&0x0F);
	return dec;
    }

void RTC_GetDate(uint32_t RTC_Format, RTC_DateTypeDef * RTC_DateStruct)
	{
	RTC_DateStruct->RTC_Year= MyStm.StRtc.Date.RTC_Year;
	RTC_DateStruct->RTC_Month= MyStm.StRtc.Date.RTC_Month;
	RTC_DateStruct->RTC_Date= MyStm.StRtc.Date.RTC_Date;	
	RTC_DateStruct->RTC_WeekDay= MyStm.StRtc.Date.RTC_WeekDay;	
	}

void RTC_GetTime(uint32_t RTC_Format, RTC_TimeTypeDef * RTC_TimeStruct)
	{	
	RTC_TimeStruct->RTC_Hours= MyStm.StRtc.Time.RTC_Hours;
	RTC_TimeStruct->RTC_Minutes= MyStm.StRtc.Time.RTC_Minutes;
	RTC_TimeStruct->RTC_Seconds= MyStm.StRtc.Time.RTC_Seconds;
	}

void RTC_SetDate(uint32_t RTC_Format, RTC_DateTypeDef * RTC_DateStruct)
	{
	MyStm.StRtc.Date= *RTC_DateStruct;

	MyStm.Update(&MyStm.StRtc, 2);	
	}

void RTC_SetTime(uint32_t RTC_Format, RTC_TimeTypeDef * RTC_TimeStruct)
	{
	MyStm.StRtc.Time= *RTC_TimeStruct;

	MyStm.Update(&MyStm.StRtc, 1);	
	}

void RTC_AlarmCmd(uint32_t RTC_Alarm, FunctionalState state)
    {
	if (RTC_Alarm == RTC_Alarm_A)
		{
		MyStm.StRtc.AlarmAEnabled= state;
		MyStm.StRtc.AlarmAOn= 0;
		}
	if (RTC_Alarm == RTC_Alarm_B)
		{
		MyStm.StRtc.AlarmBEnabled= state;
		MyStm.StRtc.AlarmBOn= 0;
		}
	}	

