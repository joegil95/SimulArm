/**
 * SD card Fat Library for STM32F4xx devices using Fatfs
 */

#include "Lib_32f4.h"

#include "SimulArm.h"

#include <tchar.h>


#define DISABLE		0
#define ENABLE		1

extern SDIO_TypeDef * SDCARD;

typedef enum
    {    
    SD_OK = 0,
	SD_ERROR
    }
SD_Error;

/**
  * @brief  SDIO Transfer state
  */
typedef enum
    {
    SD_TRANSFER_OK  = 0,
    SD_TRANSFER_BUSY,
    SD_TRANSFER_ERROR
    }
SDTransferState;

/**
  * @brief  SD Card States
  */
typedef enum
    {
    SD_CARD_READY                  = ((uint32_t)0x00000001),
    SD_CARD_IDENTIFICATION         = ((uint32_t)0x00000002),
    SD_CARD_STANDBY                = ((uint32_t)0x00000003),
    SD_CARD_TRANSFER               = ((uint32_t)0x00000004),
    SD_CARD_SENDING                = ((uint32_t)0x00000005),
    SD_CARD_RECEIVING              = ((uint32_t)0x00000006),
    SD_CARD_PROGRAMMING            = ((uint32_t)0x00000007),
    SD_CARD_DISCONNECTED           = ((uint32_t)0x00000008),
    SD_CARD_ERROR                  = ((uint32_t)0x000000FF)
    }
SDCardState;


/**
  * @brief  Card Specific Data: CSD Register
  */
typedef struct
{
__pragma(pack(push, 1)) 
    uint8_t  CSDStruct;            // CSD structure */
    uint8_t  SysSpecVersion;       // System specification version */
    uint8_t  Reserved1;            // Reserved */
    uint8_t  TAAC;                 // Data read access-time 1 */
    uint8_t  NSAC;                 // Data read access-time 2 in CLK cycles */
    uint8_t  MaxBusClkFrec;        // Max. bus clock frequency */
    uint16_t CardComdClasses;      // Card command classes */
    uint8_t  RdBlockLen;           // Max. read data block length */
    uint8_t  PartBlockRead;        // Partial blocks for read allowed */
    uint8_t  WrBlockMisalign;      // Write block misalignment */
    uint8_t  RdBlockMisalign;      // Read block misalignment */
    uint8_t  DSRImpl;              // DSR implemented */
    uint8_t  Reserved2;            // Reserved */
    uint32_t DeviceSize;           // Device Size */
    uint8_t  MaxRdCurrentVDDMin;   // Max. read current @ VDD min */
    uint8_t  MaxRdCurrentVDDMax;   // Max. read current @ VDD max */
    uint8_t  MaxWrCurrentVDDMin;   // Max. write current @ VDD min */
    uint8_t  MaxWrCurrentVDDMax;   // Max. write current @ VDD max */
    uint8_t  DeviceSizeMul;        // Device size multiplier */
    uint8_t  EraseGrSize;          // Erase group size */
    uint8_t  EraseGrMul;           // Erase group size multiplier */
    uint8_t  WrProtectGrSize;      // Write protect group size */
    uint8_t  WrProtectGrEnable;    // Write protect group enable */
    uint8_t  ManDeflECC;           // Manufacturer default ECC */
    uint8_t  WrSpeedFact;          // Write speed factor */
    uint8_t  MaxWrBlockLen;        // Max. write data block length */
    uint8_t  WriteBlockPaPartial;  // Partial blocks for write allowed */
    uint8_t  Reserved3;            // Reserded */
    uint8_t  ContentProtectAppli;  // Content protection application */
    uint8_t  FileFormatGrouop;     // File format group */
    uint8_t  CopyFlag;             // Copy flag (OTP) */
    uint8_t  PermWrProtect;        // Permanent write protection */
    uint8_t  TempWrProtect;        // Temporary write protection */
    uint8_t  FileFormat;           // File Format */
    uint8_t  ECC;                  // ECC code */
    uint8_t  CSD_CRC;              // CSD CRC */
    uint8_t  Reserved4;            // always 1*/
__pragma(pack(pop))
    }
/*__attribute__ ((packed)) */ SD_CSD;

/**
  * @brief  Card Identification Data: CID Register
  */
typedef struct
    {
__pragma(pack(push, 1)) 
    uint8_t  ManufacturerID;       // ManufacturerID */
    uint16_t OEM_AppliID;          // OEM/Application ID */
    uint32_t ProdName1;            // Product Name part1 */
    uint8_t  ProdName2;            // Product Name part2*/
    uint8_t  ProdRev;              // Product Revision */
    uint32_t ProdSN;               // Product Serial Number */
    uint8_t  Reserved1;            // Reserved1 */
    uint16_t ManufactDate;         // Manufacturing Date */
    uint8_t  CID_CRC;              // CID CRC */
    uint8_t  Reserved2;            // always 1 */
__pragma(pack(pop))
    }
/*__attribute__ ((packed)) */ SD_CID;

/**
  * @brief SD Card Status
  */
typedef struct
    {
__pragma(pack(push, 1)) 
    uint8_t DAT_BUS_WIDTH;
    uint8_t SECURED_MODE;
    uint16_t SD_CARD_TYPE;
    uint32_t SIZE_OF_PROTECTED_AREA;
    uint8_t SPEED_CLASS;
    uint8_t PERFORMANCE_MOVE;
    uint8_t AU_SIZE;
    uint16_t ERASE_SIZE;
    uint8_t ERASE_TIMEOUT;
    uint8_t ERASE_OFFSET;
__pragma(pack(pop))
    }
/*__attribute__ ((packed)) */ SD_CardStatus;


/**
  * @brief SD Card information
  */
typedef struct
    {
__pragma(pack(push, 1)) 
    SD_CSD SD_csd;
    SD_CID SD_cid;
    uint64_t CardCapacity;  // Card Capacity */
    uint32_t CardBlockSize; // Card Block Size */
    uint16_t RCA;
    uint8_t CardType;
__pragma(pack(pop))
    }
/*__attribute__ ((packed)) */ SD_CardInfo;


/**
  * @brief Supported SD Memory Cards
  */
#define SDIO_STD_CAPACITY_SD_CARD_V1_1             ((uint32_t)0x00000000)
#define SDIO_STD_CAPACITY_SD_CARD_V2_0             ((uint32_t)0x00000001)
#define SDIO_HIGH_CAPACITY_SD_CARD                 ((uint32_t)0x00000002)
#define SDIO_MULTIMEDIA_CARD                       ((uint32_t)0x00000003)
#define SDIO_SECURE_DIGITAL_IO_CARD                ((uint32_t)0x00000004)
#define SDIO_HIGH_SPEED_MULTIMEDIA_CARD            ((uint32_t)0x00000005)
#define SDIO_SECURE_DIGITAL_IO_COMBO_CARD          ((uint32_t)0x00000006)
#define SDIO_HIGH_CAPACITY_MMC_CARD                ((uint32_t)0x00000007)



#define FAT16   16
#define FAT32   32

#define	FA_OPEN_EXISTING	0x00
#define	FA_READ				0x01
#define	FA_WRITE			0x02
#define	FA_CREATE_NEW		0x04
#define	FA_CREATE_ALWAYS	0x08
#define	FA_OPEN_ALWAYS		0x10


typedef enum 
	{
	FR_OK = 0,				// (0) Success
	FR_INVALID_PARAMETER,	// (1) A parameter is invalid
	FR_DENIED				// (2) access denied
	} FRESULT;


typedef struct 
	{
	BYTE	mnt;			// 0=Not mounted, 1=mounted
	BYTE	drv;			// Physical drive letter
	} FATFS;


typedef struct 
	{
	FILE * fptr;
	} FIL;


SD_Error SD_Init(void);
SD_Error SD_GetCardInfo(SD_CardInfo *cardinfo);

int GetDiskType(char * drive);
int GetDiskVolume(char * drive, char * volname, int max);

FRESULT f_mount (FATFS* fs, const TCHAR* path, BYTE opt);			// Mount / Unmount a logical drive
FRESULT f_open (FIL* fp, const TCHAR* path, BYTE mode);				// Open or create a file

int f_putc(TCHAR c, FIL* fp);										// Put a character to the file

TCHAR* f_gets (TCHAR* buff, int len, FIL* fp);						// Get a string from the file
int f_puts (const TCHAR* str, FIL* fp);								// Put a string to the file

FRESULT f_read(FIL* fp, void* buff, UINT btr, UINT* br);			// Read data from a file
FRESULT f_write(FIL* fp, const void* buff, UINT btw, UINT* bw);		// Write data to a file

//	definie comme macro 
//	int f_printf(FIL* fp, const TCHAR* str, ...);					// Put a formatted string to the file

FRESULT f_lseek(FIL* fp, DWORD ofs);								// Move position in a file object

FRESULT f_close (FIL* fp);											// Close an open file object
FRESULT f_rename(const TCHAR* path_old, const TCHAR* path_new);		// Rename / Move a file
FRESULT f_unlink (const char * path);								// Delete an existing file










