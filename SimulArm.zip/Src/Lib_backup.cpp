/**
 * Copyright (C) JG 2020
 */


/// Backup Domain is a 4 KB sram memory
/// which is not erased on reboot
/// and which is saved via VBat when power is down


#include "Lib_32f4.h"

#include "Lib_backup.h"


static uint8_t Sram[4096];
static int Sram_Ok= 0;


 /**
  * @brief  Initialize Backup domain
  * @param  None
  * @retval None
  */
void LibBackup_Init(void)
    {
	for (int i= 0 ; i < 4096 ; i++) Sram[i]= 0;

	Sram_Ok= 1;
    }


/**
  * @brief  Read byte from Backup Domain
  * @param  addresse = offset from Backup Domain start address
  * @retval byte read at this address or 0 if error
  */
uint8_t LibBackup_Read8(uint16_t address)
    {
    uint8_t data= 0;

	if (Sram_Ok != 1) return 0xFF;

    if (address < 4096)
        data= Sram[address];
    return data;
    }

/**
  * @brief  Read word from Backup Domain
  * @param  addresse = offset from Backup Domain start address
  * @retval word read at this address or 0 if error
  */
uint16_t LibBackup_Read16(uint16_t address)
    {
    uint16_t data= 0;

	if (Sram_Ok != 1) return 0xFFFF;

    if (address < 4096)
        data= *(uint16_t *) (Sram + address);
    return data;
    }

/**
  * @brief  Read double word from Backup Domain
  * @param  addresse = offset from Backup Domain start address
  * @retval double word read at this address or 0 if error
  */
uint32_t LibBackup_Read32(uint16_t address)
    {
    uint32_t data= 0;

	if (Sram_Ok != 1) return 0xFFFFFFFF;

    if (address < 4096)
        data= *(uint32_t *) (Sram  + address);
    return data;
    }


 /**
  * @brief  Write byte to Backup Domain
  * @param  addresse = offset from Backup Domain start address
  * @param  data = byte to write at this address
  * @retval None
  */
void LibBackup_Write8(uint16_t address, uint8_t data)
    {
	if (Sram_Ok != 1) return;

    if (address < 4096)
        Sram[address]= data;
    }

/**
  * @brief  Write word to Backup Domain
  * @param  addresse = offset from Backup Domain start address
  * @param  data = word to write at this address
  * @retval None
  */
void LibBackup_Write16(uint16_t address, uint16_t data)
    {
	if (Sram_Ok != 1) return;

    if (address < 4096)
        *(uint16_t *) (Sram  + address)= data;
    }

/**
  * @brief  Write double word to Backup Domain
  * @param  addresse = offset from Backup Domain start address
  * @param  data = double word to write at this address
  * @retval None
  */
void LibBackup_Write32(uint16_t address, uint32_t data)
    {
	if (Sram_Ok != 1) return;

    if (address < 4096)
        *(uint32_t *) (Sram  + address)= data;
    }
