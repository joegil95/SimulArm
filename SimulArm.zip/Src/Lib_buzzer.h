/**
 * DAC Library for STM32F4xx devices
 */


#ifndef LibBUZZER_H
#define libBUZZER_H 900

#include "Lib_32f4.h"

#include <windows.h>

//  This library provides Buzzer functionality

/**
 * @brief  Output analog voltage to ADCx
 * @param  freq = buzz frequency in Hertz (max 32767)
 * @param  time = buzz duration in ms
 * @retval None
 */
void LibBuzzer_Output(uint16_t freq, uint32_t time);

#endif
