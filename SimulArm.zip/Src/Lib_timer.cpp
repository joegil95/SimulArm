/**
 * Copyright (C) JG 2020
 */

#include "Lib_timer.h"
#include "SimulArm.h"

extern Stm32F407 MyStm;


void LibTimer_Init(TIM_TypeDef * TIMx, uint16_t prediv, uint32_t period)
    {
	TIMx->Prescaler= prediv;
	TIMx->Period= period;
	TIMx->Mode= MODE_CTC;
	TIMx->Count= 0;
	TIMx->Interrupt= 0;
	TIMx->Pending= 0;
    }


void LibTimer_Interrupts(TIM_TypeDef * TIMx, FunctionalState state)
    {
	TIMx->Interrupt= state;

	MyStm.Update(TIMx);		
	}


ITStatus TIM_GetITStatus(TIM_TypeDef* TIMx, uint16_t TIM_IT)
	{
	return ENABLE;
	}


void TIM_ClearITPendingBit(TIM_TypeDef* TIMx, uint16_t TIM_IT)
	{
	TIMx->Pending= 0;
	}
