/**
 * Copyright (C) JG 2020
 */

/// Connecter les lignes sur les pins P8-11 du port D ou E
/// Connecter les colonnes sur les pins P12-14 du meme port


#include "lib_keypad.h"
#include "SimulArm.h"

extern Stm32F407 MyStm;

int8_t Clavier[3][4]= {{1, 4, 7, 10}, {2,5,8, 0}, {3, 6, 9, 11}};

int offset= 0;


/**
  * @brief  Initialize keypad ports
  * @param  GPIOx = GPIOD or GPIOE
  * @param	Hilo = LOW or HIGH
  * @retval None
  */
void LibKeypad_Init(GPIO_TypeDef* GPIOx, uint16_t Hilo)
    {
	if (Hilo == HIGH)
		{
		offset= 8;
		// colonnes en sorties	
		LibGPIO_Conf(GPIOx, GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14, GPIO_Mode_OUT, GPIO_OType_PP, GPIO_Speed_2MHz);
		// lignes en entrees avec pull-up
		LibGPIO_Conf(GPIOx, GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10 | GPIO_Pin_11, GPIO_Mode_IN, GPIO_PuPd_UP, GPIO_Speed_2MHz);
		// mise a 1 de toutes les colonnes
		GPIO_Write(GPIOx, 0x8000);
		}
	else
		{
		offset= 0;
		// colonnes en sorties	
		LibGPIO_Conf(GPIOx, GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6, GPIO_Mode_OUT, GPIO_OType_PP, GPIO_Speed_2MHz);
		// lignes en entrees avec pull-up
		LibGPIO_Conf(GPIOx, GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3, GPIO_Mode_IN, GPIO_PuPd_UP, GPIO_Speed_2MHz);
		// mise a 1 de toutes les colonnes
		GPIO_Write(GPIOx, 0x0080);
		}    
    }


/**
  * @brief  Get keypad touch
  * @param  GPIOx = GPIOD or GPIOE
  * @retval Pressed touch if any, or -1 if none
  */
int8_t LibKeypad_Get(GPIO_TypeDef* GPIOx)
    {
    uint16_t col, lig;
    int8_t touche= 0;

	for (int i= 0 ; i < 4 ; i++)
		{
		/*
		if ((GPIOx->Port_num == 3) && (offset+i == 2)) continue;		// Pd2 inutilisable => ignore (si poids faible)
		*/

		touche |= (MyStm.Ports[GPIOx->Port_num].getInput(offset+i) << i);
		}

	if ((touche >= 0) && (touche <= 11)) return touche;

    return -1;
    }
