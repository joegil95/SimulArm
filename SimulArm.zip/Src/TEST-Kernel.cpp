/************************************************************************************
 *  
 * Test du noyau multitaches  
 *
 ************************************************************************************/

// NB:  Toutes les variables locales doivent être static !!!

// Attention:
//      Le noyau complet utilise le Timer 5 (32 bits) qui lui est reserve
//      L'utilisation d'un unsigned long ticks permet une grande autonomie

// NB:
// Desactiver les verifications qui generent du code parasite pour verifier l'integrite de la pile
// dans Proprietes -> C/C++ -> Generation de code -> Verifications de base a l'execution = Default


#include "Lib_32f4.h"

#include "Lib_kernel.h"

#include "Lib_gpio.h"
#include "Lib_adc.h"


extern int stat[NBT];
extern unsigned priority[NBT];


// les variables globales sont principalement reservees au kernel
// les autres seront declarees dans chaque module en static imperativement !!!



// adresses des taches a initialiser
// ne pas mettre de & pour gccarm qui utilise un adressage direct
// des qu'une tache est NULL, elle et les suivantes sont ignorees
void (* taskadr[NBT])(void)= {Monitor, Task1, Task2, Task3, NULL, NULL, NULL, NULL, NULL, NULL};


// configuration particuliere des taches
void ConfigTasks(void)
	{
	priority[1]= 1;
	priority[2]= 100;
	priority[3]= 1;
	}


/// moniteur multitache
void Monitor(void)
	{
	// variables locales toutes static
	static int t;		

	while(True)
		{
		for (t= 1 ; t < NBT ; t++)
			{
			if (taskadr[t] != NULL)
				{
				if (stat[t] == STOP)
			   	stat[t]= RUN;
				}
			}

		NextTask();
		}

	while(1);	// a ajouter en mode Kernel (impossible de sortir proprement -> pbs de pile)
	}


/// Tache 1 : 4 BP sur PD0-3
void Task1(void)
	{
	// variables locales toutes static
	static uint16_t val;
	static int sync= 0;

    // configuration des ports
    LibGPIO_Conf(GPIOD, GPIO_Pin_0 | GPIO_Pin_1 |  GPIO_Pin_2 | GPIO_Pin_3, GPIO_Mode_IN, GPIO_PuPd_UP, GPIO_Speed_2MHz);
    
	while(1)
		{
	    val= ~GPIO_ReadInputData(GPIOD);

		// envoi de val dans un message si Task2 prete
		if ((ReadSemaphore("synchro", &sync)) && (sync == 1))
		   {
		   SendMessage(2, &val, sizeof(val));		// sizeof() depend du compilateur
		   WriteSemaphore("synchro", 0);
		   }

		NextTask();
		}
	}


/// Tache 2 : 4 leds sur PE0-3
void Task2(void)
	{
    // variables locales toutes static
	static uint16_t val, oldval;
	static struct TaskMsg msg;

    // initialisations	

	/// configuration des ports    
    LibGPIO_Conf(GPIOE, GPIO_Pin_0 | GPIO_Pin_1 |  GPIO_Pin_2 | GPIO_Pin_3, GPIO_Mode_OUT, GPIO_OType_PP, GPIO_Speed_2MHz);

	CreateSemaphore("synchro", 1);		 // semaphore de synchronisation

	while(1)
		{
		if (GetMessage(1, &msg))  // val dans message recu ?
		   	{
			val= * (uint16_t *) (msg.data);

			if (val != oldval)		// necessaire a cause de la lenteur de l'interface graphique
				{
				GPIO_SetBits(GPIOE, val & 0x000F);
				GPIO_ResetBits(GPIOE, ~val & 0x000F);

				oldval= val;
				}
			}

		WriteSemaphore("synchro", 1);	// pret pour envoi suivant

		NextTask();
		}
	}


/// Tache 3 : 1 led clignotante sur PE7
void Task3(void)
	{
	// variables locales toutes static
   
	// Initialisations

	// configuration des ports 
	LibGPIO_Conf(GPIOE, GPIO_Pin_7, GPIO_Mode_OUT, GPIO_OType_PP, GPIO_Speed_2MHz);

	while(1)
		{
        // allumer LED
        GPIO_SetBits(GPIOE, GPIO_Pin_7);
        TaskSleep(10);		// TaskSleep() doit toujours etre suivi de NextTask()
		NextTask();

        // eteindre LED
        GPIO_ResetBits(GPIOE, GPIO_Pin_7);
        TaskSleep(10);		// TaskSleep() doit toujours etre suivi de NextTask()
  		NextTask();
		}
	}


int main(void)
	{
	SystemInit();

	InitTasks();
	ConfigTasks();

	LibTimer_Init(TIM5, 4000, 100);
    LibTimer_Interrupts(TIM5, ENABLE);

	Monitor();
	}

