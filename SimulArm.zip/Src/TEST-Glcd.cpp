/************************************************************************************
 *  File:     main.c
 *  Purpose:  Cortex-M4 main file.
 ************************************************************************************/

#include "Lib_32f4.h"

#include "Lib_gpio.h"
#include "lib_glcd.h"


/// Connecter l'afficheur GLCD sur le port F


void main()
    {
    uint16_t cnt= 0;
 
 	GLCD_InitDisplay();
	GLCD_ClearScreen();

    GLCD_Move(0, 0, 0);
    GLCD_Write("Hello !");
    GLCD_Move(0, 2, 0);
    GLCD_ShowInt(0);

	GLCD_WriteLine(7, "Abcdefghijklmnopqrstuvwxy");

    while(True)
        {        
        cnt++;

        GLCD_Move(0, 2, 0);
        GLCD_ShowInt(cnt);
		GLCD_Write(" ");

        Lib_delay(100000);
		}        
    }

