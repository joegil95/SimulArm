/**
 * Copyright (C) JG 2020
 */

#include "Lib_32f4.h"

#include "Lib_gpio.h"
#include "Lib_spi.h"
#include "Lib_eeprom.h"

#include "SimulArm.h"


GPIO_TypeDef * GPIO_Dat= NULL;
GPIO_TypeDef * GPIO_Cmd= NULL;
SPI_TypeDef * SPI_Adr= NULL;


/**
  * @brief  Configure Eeprom data and command Ports
  * @retval None
  */
void LibEeprom_Init(GPIO_TypeDef * GPIOx, SPI_TypeDef * SPIx)
	{
	GPIO_Dat= GPIOx;
	GPIO_Cmd= GPIOx;
	SPI_Adr= SPIx;

	// 3 broches CMD en sorties
	LibGPIO_Conf(GPIOx, Pin_OE | Pin_CE | Pin_WE, GPIO_Mode_OUT, GPIO_OType_PP, GPIO_Speed_2MHz);
	// 1 broche CDM en entree
	LibGPIO_Conf(GPIOx, Pin_RB, GPIO_Mode_IN, GPIO_PuPd_UP, GPIO_Speed_2MHz);
    
	// 8 broches data en sorties
	LibGPIO_Conf(GPIOx, GPIO_Pin_Hig, GPIO_Mode_OUT, GPIO_OType_PP, GPIO_Speed_2MHz);

	GPIO_SetBits(GPIOx, Pin_OE | Pin_CE | Pin_WE);  // sorties CMD �tat haut

	LibSPI_Init(SPIx, LibSPI_DataSize_8b, SPI_BaudRatePrescaler_256);
	}


/**
  * @brief  Read data at some address in Eeprom
  * @param  Eeprom address 13 bits (0 to 8191)
  * @retval Read data (8 bits)
  */
uint8_t LibEeprom_Read(uint16_t addr)
	{
	uint16_t data = 0;

	if ((GPIO_Cmd == NULL) || (GPIO_Dat == NULL) || (SPI_Adr == NULL)) return 0;

	while (! GPIO_ReadInputDataBit(GPIO_Cmd, Pin_RB));      // attente ready

    LibSPI_Send(SPI_Adr, addr);					// envoi 16 bits d'un coup
	Lib_delay(1000);	  						// delai pour reception du message

	// 8 broches data en entrees
    LibGPIO_Conf(GPIO_Dat, GPIO_Pin_Hig, GPIO_Mode_IN, GPIO_PuPd_NOPULL, GPIO_Speed_2MHz);

/*
    GPIO_SetBits(GPIO_Cmd, Pin_WE);				// v�rification WE + CE + OE
    GPIO_SetBits(GPIO_Cmd, Pin_CE);				
    GPIO_SetBits(GPIO_Cmd, Pin_OE);
*/
///	Lib_delay(50);

    GPIO_ResetBits(GPIO_Cmd, Pin_CE);			// desactivation CE + OE
	Lib_delay(50);
	GPIO_ResetBits(GPIO_Cmd, Pin_OE);
	Lib_delay(10000);							// delai pour reception du message

	data= GPIO_ReadInputData(GPIO_Dat);			// lecture data

    GPIO_SetBits(GPIO_Cmd, Pin_OE);				// reactivation OE + CE => fin
///	Lib_delay(50);
	GPIO_SetBits(GPIO_Cmd, Pin_CE);
///	Lib_delay(100);

	return (uint8_t) (data >> 8);
	}


/**
  * @brief  Write data at some address in Eeprom
  * @param  Eeprom address 13 bits (0 to 8191)
  * @param  Data to write (8 bits)
  * @retval None
  */
void LibEeprom_Write(uint16_t addr, uint8_t data)
	{
	if ((GPIO_Cmd == NULL) || (GPIO_Dat == NULL) || (SPI_Adr == NULL))  return;

    while (! GPIO_ReadInputDataBit(GPIO_Cmd, Pin_RB));      // attente ready

	LibSPI_Send(SPI_Adr, addr);					// envoi 16 bits d'un coup (+ simple)
	Lib_delay(1000);  							// delai pour reception du message

    // 8 broches data en sorties
	LibGPIO_Conf(GPIO_Dat, GPIO_Pin_Hig, GPIO_Mode_OUT, GPIO_OType_PP, GPIO_Speed_2MHz);
    GPIO_WriteHigh(GPIO_Dat, data);				// presentation data

/*
	GPIO_SetBits(GPIO_Cmd, Pin_WE);				// v�rification WE + CE + OE
    GPIO_SetBits(GPIO_Cmd, Pin_CE);				
    GPIO_SetBits(GPIO_Cmd, Pin_OE);
*/    
///	Lib_delay(50);

    GPIO_ResetBits(GPIO_Cmd, Pin_CE);			// desactivation CE + WE
///	Lib_delay(50);
	GPIO_ResetBits(GPIO_Cmd, Pin_WE);
///	Lib_delay(100);

    GPIO_SetBits(GPIO_Cmd, Pin_WE); 			// reactivation WE => ecriture data
	Lib_delay(1000);							// delai pour reception du message

    GPIO_SetBits(GPIO_Cmd, Pin_CE);				// reactivation CE => fin




while (GPIO_ReadInputDataBit(GPIO_Cmd, Pin_RB));	    // attente validation ecriture RB = 0




	while (! GPIO_ReadInputDataBit(GPIO_Cmd, Pin_RB));	    // attente fin d'ecriture
	}


/**
  * @brief  Write some page of data (32 bytes) in Eeprom
  * @param  Eeprom page address 8 bits (0 to 255)
  * @param  Address of buffer containning data to write
  * @retval None
  */
void LibEeprom_PageWrite(uint8_t page, uint8_t *tabdata)
	{
	for(int i= 0 ; i < PAGESIZE ; i++)
	 	{
		LibEeprom_Write((page << 5) + i, tabdata[i]);
		}
	}


/**
  * @brief  Read some page of data (32 bytes) in Eeprom
  * @param  Eeprom page address 8 bits (0 to 255)
  * @param  Address of buffer to receive read data
  * @retval None
  */
void LibEeprom_PageRead(uint8_t page, uint8_t *tabdata)
	{
	if ((GPIO_Cmd == NULL) || (GPIO_Dat == NULL)) return;

	for(int i= 0 ; i < PAGESIZE ; i++)
	 	{
		tabdata[i]= LibEeprom_Read((page << 5) + i);
		}
	}
