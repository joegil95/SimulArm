/**
 * Virtual ADC Library for STM32F4xx devices
 */

#ifndef LibADC_H
#define LibADC_H 150

#include "Lib_32f4.h"


extern ADC_TypeDef * ADC1;
extern ADC_TypeDef * ADC2;
extern ADC_TypeDef * ADC3;

#define ADC_Channel_0		0
#define ADC_Channel_1		1
#define ADC_Channel_2		2
#define ADC_Channel_3		3
#define ADC_Channel_4		4
#define ADC_Channel_5		5
#define ADC_Channel_6		6
#define ADC_Channel_7		7
#define ADC_Channel_8		8
#define ADC_Channel_9		9
#define ADC_Channel_10		10
#define ADC_Channel_11		11
#define ADC_Channel_12		12
#define ADC_Channel_13		13
#define ADC_Channel_14		14
#define ADC_Channel_15		15

#define ADC_Resolution_8b			8
#define ADC_Resolution_10b			10
#define ADC_Resolution_12b			12


/**
  * @brief  Configure ADC source, channel and resolution
  * @param  ADCx = ADC1, ADC2 or ADC3
  * @param  channel = ADC_Channel_0 to ADC_Channel_15
  * @param  resol = ADC_Resolution_8b, ADC_Resolution_10b or ADC_Resolution_12b
  * @retval None
  */
void LibADC_Init(ADC_TypeDef* ADCx, uint8_t channel, uint32_t resol);

/**
  * @brief  Read from ADC source and channel
  * @param  ADCx = ADC1, ADC2 or ADC3
  * @param  channel = ADC_Channel_0 to ADC_Channel_15
  * @retval Read value
  */
uint16_t LibADC_Read(ADC_TypeDef* ADCx, uint8_t channel);

#endif