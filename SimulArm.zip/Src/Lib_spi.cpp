/**
 * Copyright (C) JG 2020
 */

#include "lib_spi.h"
#include "SimulArm.h"


extern Stm32F407 MyStm;

extern GPIO_TypeDef * GPIOA;
extern GPIO_TypeDef * GPIOB;
extern GPIO_TypeDef * GPIOC;
extern GPIO_TypeDef * GPIOD;
extern GPIO_TypeDef * GPIOE;
extern GPIO_TypeDef * GPIOF;
extern GPIO_TypeDef * GPIOG;


extern SPI_TypeDef * SPI1;
extern SPI_TypeDef * SPI2;
extern SPI_TypeDef * SPI3;


void LibSPI_Init(SPI_TypeDef* SPIx, LibSPI_DataSize_t SPI_DataSize, uint16_t SPI_BaudRatePrescaler)
    {
	if (SPIx == NULL) return;

	SPIx->Datasize= SPI_DataSize;
	SPIx->Prescaler= SPI_BaudRatePrescaler;
	}


uint16_t LibSPI_Send(SPI_TypeDef* SPIx, uint16_t data)
    {
	if (SPIx == NULL) return 0;

	MyStm.Update(SPIx, data);

	return 0;			///	A VOIR si SPI en entree (Cf Bus I2C avec passage par adresse)
	}

