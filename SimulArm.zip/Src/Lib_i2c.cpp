/**
 * Copyright (C) JG 2020
 */


#include "lib_i2c.h"
#include "SimulArm.h"


extern Stm32F407 MyStm;


/**
 * @brief  Initializes I2C
 * @param  I2Cx = I2C1, I2C2 or I2C3
 * @param  clockSpeed = Clock speed for SCL in Hertz
 * @retval None
 */
void LibI2C_MasterInit(I2C_TypeDef* I2Cx, uint32_t clockSpeed)
    {
	I2Cx->Speed= clockSpeed;
	I2Cx->Enabled= ENABLE;
    }


/**
 * @brief  Send I2C Start condition
 * @param  I2Cx = I2C1, I2C2 or I2C3
 * @param  address = slave address (1 to 127)
 * @param  direction = I2C_SEND or I2C_RECV
 * @param  ack = I2C_ACK_ENABLE or I2C_ACK_DISABLE
 * @retval 0 if OK, 1 if error
  */
int16_t LibI2C_Start(I2C_TypeDef* I2Cx, uint8_t address, uint8_t direction, uint8_t ack)
	{
	if (I2Cx->Enabled != ENABLE) return 1;

	if (direction == I2C_SEND)
		{
		MyStm.Update(I2Cx, address, I2C_STARTW, &ack);
		return 0;
		}

	if (direction == I2C_RECV)
		{
		MyStm.Update(I2Cx, address, I2C_STARTR, &ack);
		return 0;
		}

	return 1;
    }

/**
 * @brief  Send I2C Stop condition
 * @param  I2Cx = I2C1, I2C2 or I2C3
 * @retval 0 if OK, 1 if error
 */
int16_t LibI2C_Stop(I2C_TypeDef* I2Cx)
    {
	if (I2Cx->Enabled != ENABLE) return 1;

	MyStm.Update(I2Cx, 0, I2C_STOP, NULL);

	return 0;
    }


/**
 * @brief  Writes to slave
 * @param  I2Cx = I2C1, I2C2 or I2C3
 * @param  data = data to send
 * @retval None
 */
void LibI2C_Write(I2C_TypeDef* I2Cx, uint8_t data)
    {
	if (I2Cx->Enabled != ENABLE) return;

	// Send I2C data on the bus
	MyStm.Update(I2Cx, 0, I2C_WRITE, &data);
    }

/**
 * @brief  Read byte with ack (Another one will follow)
 * @param  I2Cx = I2C1, I2C2 or I2C3
 * @retval Byte from slave, or (int16_t) -1 if no data
 */
int16_t LibI2C_ReadNext(I2C_TypeDef* I2Cx)
    {
	uint8_t data= 0;

	if (I2Cx->Enabled != ENABLE) return -1;

	// Get I2C data on the bus
	MyStm.Update(I2Cx, 0, I2C_READN, &data);

	// Return data
	return data;
    }

/**
 * @brief  Read byte without ack (Last one)
 * @param  I2Cx = I2C1, I2C2 or I2C3
 * @retval Byte from slave, or (int16_t) -1 if no data
 */
int16_t LibI2C_ReadLast(I2C_TypeDef* I2Cx)
    {
	uint8_t data= 0;

	if (I2Cx->Enabled != ENABLE) return -1;

	MyStm.Update(I2Cx, 0, I2C_READL, &data);

	// Return data */
	return data;
    }


/**
 * @brief  Read register from slave
 * @param  I2Cx = I2C1, I2C2 or I2C3
 * @param  address = 7 bit slave address
 * @param  reg = register to read
 * @retval Byte from slave, or (int16_t) -1 if no data
 */
int16_t LibI2C_GetReg(I2C_TypeDef* I2Cx, uint8_t address, uint8_t reg)
    {
	int16_t data;

	LibI2C_Start(I2Cx, address, I2C_SEND, I2C_ACK_DISABLE);
	LibI2C_Write(I2Cx, reg);
	LibI2C_Stop(I2Cx);
	LibI2C_Start(I2Cx, address, I2C_RECV, I2C_ACK_DISABLE);
	data = LibI2C_ReadLast(I2Cx);
	LibI2C_Stop(I2Cx);

	return data;
    }

/**
 * @brief  Read multiple registers from slave
 * @param  I2Cx = I2C1, I2C2 or I2C3
 * @param  address = 7 bit slave address
 * @param  reg = first register to read
 * @param  data = pointer to data array to store read data
 * @param  count = number of registers ro read
 * @retval 0 if OK, 1 if error
 */
int16_t LibI2C_GetMultiReg(I2C_TypeDef* I2Cx, uint8_t address, uint8_t reg, uint8_t* data, uint16_t nb)
    {
	uint8_t i;
	int16_t dat, res= 0;

	LibI2C_Start(I2Cx, address, I2C_SEND, I2C_ACK_ENABLE);
	LibI2C_Write(I2Cx, reg);
	LibI2C_Stop(I2Cx);
	LibI2C_Start(I2Cx, address, I2C_RECV, I2C_ACK_ENABLE);
	for (i = 0; i < nb; i++)
        {
		if (i+1 < nb)
            {
            dat = LibI2C_ReadNext(I2Cx);
            if (dat == -1) res= 1;      // error
            data[i] = dat;
            }
        else    // Last byte
            {
            dat = LibI2C_ReadLast(I2Cx);
            if (dat == -1) res= 1;      // error
			data[i] = dat;
			LibI2C_Stop(I2Cx);
            }
        }
    return res;     // 0 if OK
    }

/**
 * @brief  Write register to slave
 * @param  I2Cx = I2C1, I2C2 or I2C3
 * @param  address = 7 bit slave address
 * @param  reg = register to write
 * @param  data = data to be written
 * @retval None
 */
void LibI2C_SetReg(I2C_TypeDef* I2Cx, uint8_t address, uint8_t reg, uint8_t data)
    {
	LibI2C_Start(I2Cx, address, I2C_SEND, I2C_ACK_DISABLE);
	LibI2C_Write(I2Cx, reg);
	LibI2C_Write(I2Cx, data);
	LibI2C_Stop(I2Cx);
    }

/**
 * @brief  Write multiple registers to slave
 * @param  I2Cx = I2C1, I2C2 or I2C3
 * @param  address = 7 bit slave address
 * @param  reg = first register to write
 * @param  data = pointer to data array to write
 * @param  count = number of registers to write
 * @retval None
 */

void LibI2C_SetMultiReg(I2C_TypeDef* I2Cx, uint8_t address, uint8_t reg, uint8_t* data, uint16_t nb)
    {
	uint8_t i;

	LibI2C_Start(I2Cx, address, I2C_SEND, I2C_ACK_DISABLE);
	LibI2C_Write(I2Cx, reg);
	for (i = 0; i < nb; i++)
        {
		LibI2C_Write(I2Cx, data[i]);
        }
	LibI2C_Stop(I2Cx);
    }

/**
 * @brief  Convert values from decimal to BCD format
 * @param  c = decimal value to convert
 * @retval Converted BCD value
 */
uint8_t LibI2C_DecToBcd(uint8_t c)
	{
	uint8_t bcd;

	bcd= ((c/10) << 4) + (c%10);
	return bcd;
	}

/**
 * @brief  Convert values from BCD to decimal format
 * @param  c = BCD value to convert
 * @retval Converted decimal value
 */
uint8_t LibI2C_BcdToDec(uint8_t c)
    {
	uint8_t dec;

	dec= 10*(c >> 4) + (c&0x0F);
	return dec;
    }

