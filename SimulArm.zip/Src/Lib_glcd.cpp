/**********************************************************************/
/*        Pilote du Graphic LCD 128x64 pilot� par STM32F4             */
/**********************************************************************/

#include <string.h>

#include "Lib_glcd.h"


GPIO_TypeDef * GlcdPort= GPIOF;


// Initialisation du GLCD
void GLCD_InitDisplay(void)
    {
    // Port de donn�es en sorties
	LibGPIO_Conf(GlcdPort, Pin_DATA, GPIO_Mode_OUT, GPIO_OType_PP, GPIO_Speed_2MHz);

    // Port de commande en sorties
    LibGPIO_Conf(GlcdPort, Pin_CMD, GPIO_Mode_OUT, GPIO_OType_PP, GPIO_Speed_2MHz);

	GLCD_Command(CMD_DISP_ON);

    GLCD_SelectSide(RIGHT);
    GLCD_Command(PAGE_0);
    GLCD_Command(COL_0);    
    }

// Effacement ecran GLCD
void GLCD_ClearScreen(void)
    {
    GLCD_Command(CMD_CLEAR);
    }

// Selection du demi-ecran
// side = LEFT or RIGHT
void GLCD_SelectSide(uint8_t side)
    {
    if(side==LEFT)
		GLCD_Command(CMD_LEFT);
    if(side==RIGHT)
		GLCD_Command(CMD_RIGHT);

	GLCD_Command(PAGE_0);		// Ligne 0 
    GLCD_Command(COL_0);   	   	// Colonne 0
    }

// Envoi d'une commande au LCD
void GLCD_Command(uint8_t cmd)
    {
    GPIO_Write(GlcdPort, ((uint16_t) cmd) & ~Pin_DI);	// Mode commande 
    }

// Envoi d'une donnee au LCD
// Incr�mentation auto de la colonne � chaque �criture
void GLCD_DataWrite(uint8_t data)
    {
    GPIO_Write(GlcdPort, ((uint16_t) data) | Pin_DI);	// Mode data
    }

// Deplacement 
void GLCD_Move(uint8_t side, uint8_t page, uint8_t col)
	{
    GLCD_SelectSide(side);              // Selection demi-ecran

    GLCD_Command(PAGE_0 | page);     	// Selection page
    GLCD_Command(COL_0 | col);          // Selection colonne
	}

// Ecriture d'un caractere
void GLCD_WriteChar(uint8_t c)
    {
    uint8_t i;

    i = (c - 0x20);
    for (int j = 0; j < 5; j++)
          {
          GLCD_DataWrite(FontSystem5x8[i][j]);		  
          }
    }

// Ecriture d'une chaine
void GLCD_Write(char * chaine)
    {
	for (int n= 0 ; chaine[n] != 0 ; n++)
		GLCD_WriteChar(chaine[n]);
    }

// Ecriture d'une chaine sur une ligne entiere jusqu'a concurrence de 25 caraceres
void GLCD_WriteLine(uint8_t page, char * chaine)
    {
    int i, len;
    char ligne[30];

    strcpy(ligne, (char *) chaine);
    len= strlen((char *) chaine);
    for (int n= len ; n < sizeof(ligne); n++)    // complete avec espaces
        ligne[n]= ' ';

    GLCD_Move(LEFT, page, 0);

    for (int n= 0 ; n < 12 ; n++)
		GLCD_WriteChar(ligne[n]);

    // ecriture des 4 premieres colonnes du 13e caractere
    i = (ligne[13] - 0x20);
    for (int j = 0; j < 4; j++)
        {
        GLCD_DataWrite(FontSystem5x8[i][j]);
        }
    // ecriture de la 5e colonne du 13e caractere sur page de droite
    GLCD_Move(RIGHT, page, 0);
    GLCD_DataWrite(FontSystem5x8[i][5]);

    for (int n= 13 ; n < 25 ; n++)
		GLCD_WriteChar(ligne[n]);

    // effacement des 3 dernieres colonnes de la ligne
    for (int j = 0; j < 3; j++)
        {
        GLCD_DataWrite(0x00);
        }

    }

// Affichage d'une variale de type entier
void GLCD_ShowInt(int entier)
	{
   	int compteur = 0;
   	uint8_t caracteres[10];    // Un entier comporte un maximum de 10 digits

   	// Si l'entier vaut 0, on l'affiche tout de suite
   	if(entier == 0)
   		{
      	GLCD_WriteChar('0');
   		}
   	else
   		{
      	// Gestion de l'affichage du signe moins dans le cas d'un nombre n�gatif
      	if(entier < 0)
      		{
        	GLCD_WriteChar('-');
        	entier = -entier;       // Repassage du nombre en positif
      		}

      	// Construction de la cha�ne de caract�res correspondante
      	// Principe: divisions successives par 10 pour r�cup�rer chaque digit
      	// jusqu'� arriver � 0.
      	while(entier>0 && compteur <= 10)
      		{
        	caracteres[compteur] = entier % 10;  // R�cup�ration du digit actuel
        	entier /= 10;   // Passage au digit suivant
        	compteur++;
      		}

      	// Affichage de la cha�ne (on commence par les derniers digit
      	// puisque la construction s'est faites dans le sens inverse)
      	for(;compteur>0; compteur--)
      		{
        	GLCD_WriteChar('0' + caracteres[compteur-1]);
      		}
   		}
	}


