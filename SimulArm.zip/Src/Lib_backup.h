/**
 * Virtual Backup Memory Library for STM32F4xx devices
 */


#include "Lib_32f4.h"


void LibBackup_Init(void);

uint8_t LibBackup_Read8(uint16_t address);
uint16_t LibBackup_Read16(uint16_t address);
uint32_t LibBackup_Read32(uint16_t address);

void LibBackup_Write8(uint16_t address, uint8_t data);
void LibBackup_Write16(uint16_t address, uint16_t data);
void LibBackup_Write32(uint16_t address, uint32_t data);
