/*
Gestion des interruptions
D�finir dans le programme la routine associ�e comme ci-dessous.
*/

void Interrupts_Enable(void);
void Interrupts_Disable(void);


void WWDG_Handler(void);		        	// WATCHDOG=0
void PVD_Handler(void);		        	    // PVD=1
void TAMP_STAMP_Handler(void);	    	    // TAMPER=2
void RTC_WKUP_Handler(void);		        // RTC=3
void FLASH_Handler(void);		    	    // FLASH=4
void RCC_Handler(void);			            // RCC=5
void EXTI0_Handler(void);		       	    // EXTI=6
void EXTI1_Handler(void);		    	    // EXTI=7
void EXTI2_Handler(void);			        // EXTI=8
void EXTI3_Handler(void);			        // EXTI=9
void EXTI4_Handler(void);			        // EXTI=10
void DMA1_S0_Handler(void);	                // DMA1=11
void DMA1_S1_Handler(void);     	        // DMA1=12
void DMA1_S2_Handler(void);     	        // DMA1=13
void DMA1_S3_Handler(void);     	        // DMA1=14
void DMA1_S4_Handler(void);     	        // DMA1=15
void DMA1_S5_Handler(void);     	        // DMA1=16
void DMA1_S6_Handler(void);    	            // DMA1= 17
void ADC_Handler(void);		        	    // ADC1-2-3=18
void CAN1_TX_Handler(void);		            // CAN1=19
void CAN1_RX0_Handler(void);	        	// CAN1=20
void CAN1_RX1_Handler(void);	        	// CAN1=21
void CAN1_SCE_Handler(void);	        	// CAN1=22
void EXTI9_5_Handler(void);	        	    // EXTI=23
void TIM1_BRK_TIM9_Handler(void);	        // TIM1=24
void TIM1_UP_TIM10_Handler(void);	        // TIM1=25
void TIM1_TRG_COM_TIM11_Handler(void);	    // TIM1=26
void TIM1_CC_Handler(void);		            // TIM1=27
void TIM2_Handler(void);   		            // TIM2=28
void TIM3_Handler(void);			        // TIM3=29
void TIM4_Handler(void);			        // TIM4=30
void I2C1_EV_Handler(void);	        	    // I2C1=31
void I2C1_ER_Handler(void);	        	    // I2C1=32
void I2C2_EV_Handler(void);	        	    // I2C2=33
void I2C2_ER_Handler(void);	        	    // I2C2=34
void SPI1_Handler(void);		        	// SPI1=35
void SPI2_Handler(void);		        	// SPI2=36
void USART1_Handler(void);	        	    // USART1=37
void USART2_Handler(void);	                // USART2=38
void USART3_Handler(void);	                // USART3=39
void EXTI15_10_Handler(void);               // EXTI=40
void RTC_ALARM_Handler(void);	            // RTC=41
void OTG_FS_WKUP_Handler(void);	            // USB=42
void TIM8_BRK_TIM12_Handler(void);          // TIM8=43
void TIM8_UP_TIM13_Handler(void);           // TIM8=44
void TIM8_TRG_COM_TIM14_Handler(void);	    // TIM8=45
void TIM8_CC_Handler(void);		            // TIM8=46
void DMA1_S7_Handler(void);	                // DMA1=47
void FSMC_Handler(void);			        // FSMC=48
void SDIO_Handler(void);			        // SDIO=49
void TIM5_Handler(void);			        // TIM5=50
void SPI3_Handler(void);			        // SPI3=51
void UART4_Handler(void);			        // UART4=52
void UART5_Handler(void);			        // UART5=53
void TIM6_DAC_Handler(void);		        // TIM6-DAC1=54
void TIM7_Handler(void);			        // TIM7=55
void DMA2_S0_Handler(void);	                // DMA2=56
void DMA2_S1_Handler(void);	                // DMA2=57
void DMA2_S2_Handler(void);	                // DMA2=58
void DMA2_S3_Handler(void);	                // DMA2=59
void DMA2_S4_Handler(void);	                // DMA2=60
void ETH_Handler(void);			            // Ethernet=61
void ETH_WKUP_Handler(void);		        // Ethernet=62
void CAN2_TX_Handler(void);		            // CAN2=63
void CAN2_RX0_Handler(void);		        // CAN2=64
void CAN2_RX1_Handler(void);		        // CAN2=65
void CAN2_SCE_Handler(void);		        // CAN2=66
void OTG_FS_Handler(void);		            // USB=67
void DMA2_S5(void);	                        // DMA2=68
void DMA2_S6(void);	                        // DMA2=69
void DMA2_S7(void);	                        // DMA2=70
void USART6_Handler(void);		            // USART6=71
void I2C3_EV_Handler(void);		            // I2C3=72
void I2C3_ER_Handler(void);		            // I2C3=73
void OTG_HS_EP1_OUT_Handler(void);	        // USB=74
void OTG_HS_EP1_IN_Handler(void);	        // USB=75
void OTG_HS_WKUP_Handler(void);		        // USB=76
void OTG_HS_Handler(void);		            // USB=77
void DCMI_Handler(void);			        // DCMI=78
void CRYP_Handler(void);			        // CRYP=79
void HASH_RNG_Handler(void);		        // Hash=80
void FPU_Handler(void);			            // FPU=81


