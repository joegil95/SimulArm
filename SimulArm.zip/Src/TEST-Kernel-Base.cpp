/************************************************************************************
 *  
 * Test du noyau multitaches  
 *
 ************************************************************************************/

// NB:  Toutes les variables locales doivent être static !!!

// NB:
// Desactiver les verifications qui generent du code parasite pour verifier l'integrite de la pile
// dans Proprietes -> C/C++ -> Generation de code -> Verifications de base a l'execution = Default


#include "Lib_32f4.h"

#include "Lib_kernel.h"

#include "Lib_gpio.h"
#include "Lib_adc.h"


extern int stat[NBT];
extern unsigned priority[NBT];


// les variables globales sont principalement reservees au kernel
// les autres seront declarees dans chaque module en static imperativement !!!

// a defaut d'IPC on utilise une variable globale
uint16_t val;

// adresses des taches a initialiser
// ne pas mettre de & pour gccarm qui utilise un adressage direct
// des qu'une tache est NULL, elle et les suivantes sont ignorees
void (* taskadr[NBT])(void)= {Monitor, Task1, Task2, NULL, NULL, NULL, NULL, NULL, NULL, NULL};


// configuration particuliere des taches
void ConfigTasks(void)
	{

	}


/// moniteur multitache
void Monitor(void)
	{
	// variables locales toutes static
	static int t;		

	while(True)
		{
		for (t= 1 ; t < NBT ; t++)
			{
			if (taskadr[t] != NULL)
				{
				if (stat[t] == STOP)
			   	stat[t]= RUN;
				}
			}

		NextTask();
		}

	while(1);	// a ajouter en mode Kernel (impossible de sortir proprement -> pbs de pile)
	}


/// Tache 1 : 4 BP sur PD0-3
void Task1(void)
	{
	// variables locales toutes static
	
    // configuration des ports
    LibGPIO_Conf(GPIOD, GPIO_Pin_0 | GPIO_Pin_1 |  GPIO_Pin_2 | GPIO_Pin_3, GPIO_Mode_IN, GPIO_PuPd_UP, GPIO_Speed_2MHz);
    
	while(1)
		{
	    val= ~GPIO_ReadInputData(GPIOD);

		NextTask();
		}
	}


/// Tache 2 : 4 leds sur PE0-3
void Task2(void)
	{
    // variables locales toutes static
	static uint16_t oldval;

    // initialisations	

	/// configuration des ports    
    LibGPIO_Conf(GPIOE, GPIO_Pin_0 | GPIO_Pin_1 |  GPIO_Pin_2 | GPIO_Pin_3, GPIO_Mode_OUT, GPIO_OType_PP, GPIO_Speed_2MHz);

	while(1)
		{
		if (val != oldval)		// necessaire a cause de la lenteur de l'interface graphique
			{
			GPIO_SetBits(GPIOE, val & 0x000F);
			GPIO_ResetBits(GPIOE, ~val & 0x000F);

			oldval= val;
			}		

		NextTask();
		}
	}


int main(void)
	{
	SystemInit();

	InitTasks();
	ConfigTasks();

	Monitor();
	}

