#include "Lib_interrupts.h"

extern void Ints_Enable(unsigned state);

void Interrupts_Enable(void)
	{
	Ints_Enable(1);
	}

void Interrupts_Disable(void)
	{
	Ints_Enable(0);
	}
