/**
 * Copyright (C) JG 2020
 */

#include <windows.h>

#include "lib_uart.h"
#include "lib_gpio.h"


/**
 * @brief  Initialize USART peripheral and corresponding pins
 * @param  USARTx = USART1, USART2, USART3, UART4, UART5 or USART6
 * @param  baudrate = standard baudrate value from 1200 to 115200
 * @param  datalen = USART_WordLength_8b or USART_WordLength_9b
 * @param  parity = USART_Parity_No or USART_Parity_Even or USART_Parity_Odd
 * @param  stops = USART_StopBits_1 or USART_StopBits_2
 * @retval None
 */
void LibUart_Init(USART_TypeDef* USARTx, uint32_t baudrate, uint16_t datalen, uint16_t parity, uint16_t stops)
    {
	char comport[100]= "";

	USARTx->USART_Id= 0;
	if (USARTx == USART1) USARTx->USART_Id= 1;
	if (USARTx == USART2) USARTx->USART_Id= 2;
	if (USARTx == USART3) USARTx->USART_Id= 3;
	if (USARTx == UART4) USARTx->USART_Id= 4;
	if (USARTx == UART5) USARTx->USART_Id= 5;
	if (USARTx == USART6) USARTx->USART_Id= 6;

	USARTx->USART_BaudRate= baudrate;	
	USARTx->USART_Parity= parity;
	USARTx->USART_StopBits= stops;
	USARTx->USART_WordLength= datalen;

	USARTx->USART_Mode= USART_Mode_Tx | USART_Mode_Rx;          // full-duplex TX + RX

	wsprintf(comport, "\\\\.\\COM%c", '0'+USARTx->USART_Id);
	USARTx->USART_Hd= OpenComPort(comport, datalen, stops, parity, baudrate);

	if (USARTx->USART_Hd == INVALID_HANDLE_VALUE)
		::MessageBox(NULL, "Attention: UART inaccessible", "Erreur", MB_OK);
    }


/**
 * @brief  Get character from UART (blocking function)
 * @param  USARTx = USART1, USART2, USART3, UART4, UART5 or USART6
 * @retval Received character
 */
uint8_t LibUart_Getc(USART_TypeDef* USARTx)
	{
    uint8_t c= 0;

	if ((USARTx->USART_Hd != 0) && (USARTx->USART_Hd != INVALID_HANDLE_VALUE))
		RecvComPort(USARTx->USART_Hd, (char *) &c, 1);

	return c;
    }


/**
 * @brief  Send character via UART
 * @param  USARTx = USART1, USART2, USART3, UART4, UART5 or USART6
 * @param  c = character to be send
 * @retval None
 */
void LibUart_Putc(USART_TypeDef* USARTx, char c)
    {
	if ((USARTx->USART_Hd != 0) && (USARTx->USART_Hd != INVALID_HANDLE_VALUE))
		SendComPort(USARTx->USART_Hd, &c, 1);
    }


/**
 * @brief  Test if character was received via UART
 * @param  USARTx = USART1, USART2, USART3, UART4, UART5 or USART6
 * @retval True if any, false if none
 */
uint8_t LibUart_Received_Data(USART_TypeDef* USARTx)
	{
	DWORD nb= 0, erreur;
	COMSTAT state;

	if ((USARTx->USART_Hd != 0) && (USARTx->USART_Hd != INVALID_HANDLE_VALUE))
		{
		ClearCommError(USARTx->USART_Hd, &erreur, &state);
		if (state.cbInQue > 0) return 1;
		}

	return 0;
	}


/**
 * Internal functions
 */

HANDLE OpenComPort(char * port, BYTE data, BYTE stop, BYTE parity, DWORD speed)
	{
    HANDLE hPort;
	BOOL res;
	DCB dcb;	// structure Device Control Block

	hPort= CreateFileA(port, GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, 0, NULL);
	if (hPort == INVALID_HANDLE_VALUE)
    	{
    	return INVALID_HANDLE_VALUE;
        }

	res = GetCommState(hPort, &dcb);	// Lecture des parametres
	if (res == 0)
    	{
    	return INVALID_HANDLE_VALUE;
        }
	else
		{
		dcb.ByteSize= data;			// Nombre de bits de Donnees
		dcb.StopBits= stop;		   	// Nombre de bits de Stop
		dcb.Parity= parity;	   		// Type de parite
		dcb.BaudRate= speed;   		// Vitesse de transfert des donnees
		SetCommState(hPort, &dcb);	// Ecriture des parametres.
		}

    return hPort;
	}

void SendComPort(HANDLE hPort, char * dat, unsigned n)
	{
    DWORD nb, erreur;
	COMSTAT state;
    unsigned i;

    for (i= 0 ; i < n ; i++)
    	{
	    WriteFile(hPort, dat+i, 1, &nb, NULL);
		Sleep(5);		// tempo pour �C
	    do  // attend la fin de la transmission
    		{
        	ClearCommError(hPort, &erreur, &state);
	        }
    	while (state.cbOutQue > 0);
        }
    }

unsigned RecvComPort(HANDLE hPort, char * dat, unsigned n)
	{
    DWORD nb= 0, erreur;
	COMSTAT state;

    do  // attend la reception du nb d'octets voulu
    	{
        ClearCommError(hPort, &erreur, &state);
        }
    while (state.cbInQue < n);

    // n = 0 => lecture non bloquante
    if (n == 0) n= 1;
    // lit 1 octet si il y a !

	if (state.cbInQue > 0) ReadFile(hPort , dat, n, &nb , NULL);
    return nb;
    }

void FlushComPort(HANDLE hPort)
	{
    DWORD nb, erreur;
	COMSTAT state;
    unsigned i, n;
    char truc;

    ClearCommError(hPort, &erreur, &state);
    n= state.cbInQue;

    for (i= 0 ; i < n ; i++)
		ReadFile(hPort , &truc, 1, &nb , NULL);
	}

