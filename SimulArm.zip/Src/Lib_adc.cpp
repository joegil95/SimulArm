/**
 * Copyright (C) JG 2020
 */

#include "Lib_adc.h"
#include "SimulArm.h"


extern Stm32F407 MyStm;

extern GPIO_TypeDef * GPIOA;
extern GPIO_TypeDef * GPIOB;
extern GPIO_TypeDef * GPIOC;
extern GPIO_TypeDef * GPIOD;
extern GPIO_TypeDef * GPIOE;
extern GPIO_TypeDef * GPIOF;
extern GPIO_TypeDef * GPIOG;

extern ADC_TypeDef * ADC1;
extern ADC_TypeDef * ADC2;
extern ADC_TypeDef * ADC3;

void LibADC_Init(ADC_TypeDef* ADCx, uint8_t channel, uint32_t resol)
	{
	ADCx->resol[channel]= resol;
	}


uint16_t LibADC_Read(ADC_TypeDef* ADCx, uint8_t channel)
	{
	uint16_t res= 0;

	if (ADCx == ADC1)		// ADC1 sur GPIOA
		{
		res = MyStm.Ports[GPIOA->Port_num].getInput(channel);
		}
	if (ADCx == ADC2)		// ADC2 sur GPIOB (en realite GPIOA aussi)
		{
		res = MyStm.Ports[GPIOB->Port_num].getInput(channel);
		}
	if (ADCx == ADC3)		// ADC3 sur GPIOF
		{
		res = MyStm.Ports[GPIOF->Port_num].getInput(channel);
		}

	return res;
	}
