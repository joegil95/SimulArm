/*
Astuce pour palier au non support par VC++ des constantes binaires de la forme 0b........
Remplacer par b8(........)
Fonctionne avec des valeurs 8 bits
*/


#define BIN(x) ((x&0x0000000FLU)?1:0)\
              +((x&0x000000F0LU)?2:0)\
              +((x&0x00000F00LU)?4:0)\
              +((x&0x0000F000LU)?8:0)\
              +((x&0x000F0000LU)?16:0)\
              +((x&0x00F00000LU)?32:0)\
              +((x&0x0F000000LU)?64:0)\
              +((x&0xF0000000LU)?128:0)

#define HEX(n) 0x##n##LU

#define b8(d) ((unsigned char) BIN(HEX(d)))