
#include "Lib_kernel.h"

int activtask= 0;  	 		   	// tache active
int nexttask= 0;				// tache suivante (laisser en global)
unsigned long oldret= 0;		// laisser en global pour adressage
unsigned long newret= 0;        // laisser en global pour adressage

unsigned long taskret[NBT];			// adresses de retour des taches
int stat[NBT];	  		  			// status des taches

extern void (* taskadr[NBT])(void);


void InitTasks(void)
	{
	int t;

	for (t= 0 ; t < NBT ; t++)
		{
		stat[t]= STOP;
		}
	stat[0]= RUN;

	for (t= 0 ; t < NBT ; t++)
		{
		// gestion des adresses pour gccarm
		taskret[t]= ((unsigned *) taskadr)[t];
		}
	}
	
	
// rotation des taches
void NextTask(void)
	{
    static int task= 0;
    static unsigned long p;
	static unsigned s;

	__asm
		{
		PUSH EAX
		PUSH EBX
		PUSH ECX
		PUSH EDX
		PUSH EDI
		PUSH ESI
		PUSH DS
		PUSH ES
		PUSH FS
		PUSH GS
		PUSHFD
		}

	task= activtask;

	// rotation des taches 

	  	{
		do
	  		{
			task++;						// tache suivante
			if (task >= NBT) task= 0;
			if (taskret[task] == NULL) task= 0;

			}
		while(stat[task] != RUN);
		}

	nexttask= task;			 // nouvelle tache elue

	newret= taskret[nexttask];

    __asm			// recuperation adresse de retour dans oldret
		{
		MOV EDX, ESP
		MOV ESP, EBP
		POP EAX				// Pushed EBP
		POP EAX				// Ret Adr

		MOV oldret, EAX

		MOV ESP, EDX
		}

	taskret[activtask]= oldret;
	activtask= nexttask;

	__asm
		{
		POPFD
		POP GS
		POP FS
		POP ES
		POP DS
		POP ESI
		POP EDI
		POP EDX
		POP ECX
		POP EBX
		POP EAX				
		}

	__asm
		{
		PUSH EAX
		PUSH EDX
		MOV EDX, ESP
		MOV ESP, EBP
		POP EAX				// Pushed EBP
		POP EAX				// Ret Adr

		MOV EAX, newret		// Modification ret Adr
		PUSH EAX

		MOV ESP, EDX
		POP EDX
		POP EAX
		}
	}

