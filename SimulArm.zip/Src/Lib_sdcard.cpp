/**
 * Copyright (C) JG 2020
 */

/* Includes ------------------------------------------------------------------*/

#include "Lib_32f4.h"

#include "Lib_sdcard.h"

#include <string.h>


extern Stm32F407 MyStm;

static uint32_t CardType =  SDIO_STD_CAPACITY_SD_CARD_V1_1;			// carte SDSC
static uint32_t CSD_Tab[4], CID_Tab[4], RCA = 0x0001;
static uint8_t SDSTATUS_Tab[16];

// structure qui contient le CSD, CID, capacit�, type... apres SD_Init() OK
SD_CardInfo SDCardInfo;

FATFS * filesys= NULL;


/**
  * @brief  Initializes the SD Card and put it into StandBy State (Ready for data transfer).
  * @param  None
  * @retval SD_Error: SD Card Error code.
  */
SD_Error SD_Init(void)
    {
    SD_Error errorstatus = SD_OK;

	SDCARD->Enabled= DISABLE;

	if ((MyStm.SDIO_Status & SDIO_CON) == 0) return SD_ERROR;		// port != SDIO
	if ((MyStm.SDIO_Status & SDIO_IN) == 0) return SD_ERROR;		// carte non inseree

    errorstatus = SD_GetCardInfo(&SDCardInfo);
	if (errorstatus == SD_OK) SDCARD->Enabled= ENABLE;
	
    return(errorstatus);
    }

	
/**
  * @brief  Returns information about specific card.
  * @param  cardinfo: pointer to a SD_CardInfo structure that contains all SD card
  *         information.
  * @retval SD_Error: SD Card Error code.
  */
SD_Error SD_GetCardInfo(SD_CardInfo *cardinfo)
    {
    SD_Error errorstatus = SD_OK;
    uint8_t tmp = 0;

    cardinfo->CardType = (uint8_t)CardType;
    cardinfo->RCA = (uint16_t)RCA;

	// Les tableau CSD_Tab[] et CID_Tab[] sont normalement initialises par SD_InitializeCards()
	// On simule ici une carte SD Sandisk de 64 MO standard v1

	CSD_Tab[0]= 0x000E0032;
	CSD_Tab[1]= 0x5B5903B7;
	CSD_Tab[2]= 0xFEF9FF80;
	CSD_Tab[3]= 0x1240008B;

	CID_Tab[0]= 0x03534453;
	CID_Tab[1]= 0x44363420;
	CID_Tab[2]= 0x1298625D;
	CID_Tab[3]= 0xEB0102A1;

    // Byte 0
    tmp = (uint8_t)((CSD_Tab[0] & 0xFF000000) >> 24);
    cardinfo->SD_csd.CSDStruct = (tmp & 0xC0) >> 6;
    cardinfo->SD_csd.SysSpecVersion = (tmp & 0x3C) >> 2;
    cardinfo->SD_csd.Reserved1 = tmp & 0x03;

    // Byte 1 
    tmp = (uint8_t)((CSD_Tab[0] & 0x00FF0000) >> 16);
    cardinfo->SD_csd.TAAC = tmp;

    // Byte 2 
    tmp = (uint8_t)((CSD_Tab[0] & 0x0000FF00) >> 8);
    cardinfo->SD_csd.NSAC = tmp;

    // Byte 3 
    tmp = (uint8_t)(CSD_Tab[0] & 0x000000FF);
    cardinfo->SD_csd.MaxBusClkFrec = tmp;

    // Byte 4 
    tmp = (uint8_t)((CSD_Tab[1] & 0xFF000000) >> 24);
    cardinfo->SD_csd.CardComdClasses = tmp << 4;

    // Byte 5 
    tmp = (uint8_t)((CSD_Tab[1] & 0x00FF0000) >> 16);
    cardinfo->SD_csd.CardComdClasses |= (tmp & 0xF0) >> 4;
    cardinfo->SD_csd.RdBlockLen = tmp & 0x0F;

    // Byte 6 
    tmp = (uint8_t)((CSD_Tab[1] & 0x0000FF00) >> 8);
    cardinfo->SD_csd.PartBlockRead = (tmp & 0x80) >> 7;
    cardinfo->SD_csd.WrBlockMisalign = (tmp & 0x40) >> 6;
    cardinfo->SD_csd.RdBlockMisalign = (tmp & 0x20) >> 5;
    cardinfo->SD_csd.DSRImpl = (tmp & 0x10) >> 4;
    cardinfo->SD_csd.Reserved2 = 0; // Reserved 

	if ((CardType == SDIO_STD_CAPACITY_SD_CARD_V1_1) || (CardType == SDIO_STD_CAPACITY_SD_CARD_V2_0))
        {
        cardinfo->SD_csd.DeviceSize = (tmp & 0x03) << 10;

        /*!< Byte 7 */
        tmp = (uint8_t)(CSD_Tab[1] & 0x000000FF);
        cardinfo->SD_csd.DeviceSize |= (tmp) << 2;

        /*!< Byte 8 */
        tmp = (uint8_t)((CSD_Tab[2] & 0xFF000000) >> 24);
        cardinfo->SD_csd.DeviceSize |= (tmp & 0xC0) >> 6;

        cardinfo->SD_csd.MaxRdCurrentVDDMin = (tmp & 0x38) >> 3;
        cardinfo->SD_csd.MaxRdCurrentVDDMax = (tmp & 0x07);

        /*!< Byte 9 */
        tmp = (uint8_t)((CSD_Tab[2] & 0x00FF0000) >> 16);
        cardinfo->SD_csd.MaxWrCurrentVDDMin = (tmp & 0xE0) >> 5;
        cardinfo->SD_csd.MaxWrCurrentVDDMax = (tmp & 0x1C) >> 2;
        cardinfo->SD_csd.DeviceSizeMul = (tmp & 0x03) << 1;
        /*!< Byte 10 */
        tmp = (uint8_t)((CSD_Tab[2] & 0x0000FF00) >> 8);
        cardinfo->SD_csd.DeviceSizeMul |= (tmp & 0x80) >> 7;

        cardinfo->CardCapacity = (cardinfo->SD_csd.DeviceSize + 1) ;
        cardinfo->CardCapacity *= (1 << (cardinfo->SD_csd.DeviceSizeMul + 2));
        cardinfo->CardBlockSize = 1 << (cardinfo->SD_csd.RdBlockLen);
        cardinfo->CardCapacity *= cardinfo->CardBlockSize;
        }
    else if (CardType == SDIO_HIGH_CAPACITY_SD_CARD)
        {
        // Byte 7 
        tmp = (uint8_t)(CSD_Tab[1] & 0x000000FF);
        cardinfo->SD_csd.DeviceSize = (tmp & 0x3F) << 16;

        // Byte 8 
        tmp = (uint8_t)((CSD_Tab[2] & 0xFF000000) >> 24);

        cardinfo->SD_csd.DeviceSize |= (tmp << 8);

        // Byte 9 
        tmp = (uint8_t)((CSD_Tab[2] & 0x00FF0000) >> 16);

        cardinfo->SD_csd.DeviceSize |= (tmp);

        // Byte 10 
        tmp = (uint8_t)((CSD_Tab[2] & 0x0000FF00) >> 8);

        cardinfo->CardCapacity = ((uint64_t)cardinfo->SD_csd.DeviceSize + 1) * 512 * 1024;
        cardinfo->CardBlockSize = 512;
        }

    cardinfo->SD_csd.EraseGrSize = (tmp & 0x40) >> 6;
    cardinfo->SD_csd.EraseGrMul = (tmp & 0x3F) << 1;

    // Byte 11 
    tmp = (uint8_t)(CSD_Tab[2] & 0x000000FF);
    cardinfo->SD_csd.EraseGrMul |= (tmp & 0x80) >> 7;
    cardinfo->SD_csd.WrProtectGrSize = (tmp & 0x7F);

    // Byte 12 
    tmp = (uint8_t)((CSD_Tab[3] & 0xFF000000) >> 24);
    cardinfo->SD_csd.WrProtectGrEnable = (tmp & 0x80) >> 7;
    cardinfo->SD_csd.ManDeflECC = (tmp & 0x60) >> 5;
    cardinfo->SD_csd.WrSpeedFact = (tmp & 0x1C) >> 2;
    cardinfo->SD_csd.MaxWrBlockLen = (tmp & 0x03) << 2;

    // Byte 13 
    tmp = (uint8_t)((CSD_Tab[3] & 0x00FF0000) >> 16);
    cardinfo->SD_csd.MaxWrBlockLen |= (tmp & 0xC0) >> 6;
    cardinfo->SD_csd.WriteBlockPaPartial = (tmp & 0x20) >> 5;
    cardinfo->SD_csd.Reserved3 = 0;
    cardinfo->SD_csd.ContentProtectAppli = (tmp & 0x01);

    // Byte 14 
    tmp = (uint8_t)((CSD_Tab[3] & 0x0000FF00) >> 8);
    cardinfo->SD_csd.FileFormatGrouop = (tmp & 0x80) >> 7;
    cardinfo->SD_csd.CopyFlag = (tmp & 0x40) >> 6;
    cardinfo->SD_csd.PermWrProtect = (tmp & 0x20) >> 5;
    cardinfo->SD_csd.TempWrProtect = (tmp & 0x10) >> 4;
    cardinfo->SD_csd.FileFormat = (tmp & 0x0C) >> 2;
    cardinfo->SD_csd.ECC = (tmp & 0x03);

    // Byte 15 
    tmp = (uint8_t)(CSD_Tab[3] & 0x000000FF);
    cardinfo->SD_csd.CSD_CRC = (tmp & 0xFE) >> 1;
    cardinfo->SD_csd.Reserved4 = 1;


    // Byte 0 
    tmp = (uint8_t)((CID_Tab[0] & 0xFF000000) >> 24);
    cardinfo->SD_cid.ManufacturerID = tmp;

    // Byte 1 
    tmp = (uint8_t)((CID_Tab[0] & 0x00FF0000) >> 16);
    cardinfo->SD_cid.OEM_AppliID = tmp << 8;

    // Byte 2 
    tmp = (uint8_t)((CID_Tab[0] & 0x000000FF00) >> 8);
    cardinfo->SD_cid.OEM_AppliID |= tmp;

    // Byte 3 
    tmp = (uint8_t)(CID_Tab[0] & 0x000000FF);
    cardinfo->SD_cid.ProdName1 = tmp << 24;

    // Byte 4 
    tmp = (uint8_t)((CID_Tab[1] & 0xFF000000) >> 24);
    cardinfo->SD_cid.ProdName1 |= tmp << 16;

    // Byte 5 
    tmp = (uint8_t)((CID_Tab[1] & 0x00FF0000) >> 16);
    cardinfo->SD_cid.ProdName1 |= tmp << 8;

    // Byte 6 
    tmp = (uint8_t)((CID_Tab[1] & 0x0000FF00) >> 8);
    cardinfo->SD_cid.ProdName1 |= tmp;

    // Byte 7 
    tmp = (uint8_t)(CID_Tab[1] & 0x000000FF);
    cardinfo->SD_cid.ProdName2 = tmp;

    // Byte 8 
    tmp = (uint8_t)((CID_Tab[2] & 0xFF000000) >> 24);
    cardinfo->SD_cid.ProdRev = tmp;

    // Byte 9 
    tmp = (uint8_t)((CID_Tab[2] & 0x00FF0000) >> 16);
    cardinfo->SD_cid.ProdSN = tmp << 24;

    // Byte 10 
    tmp = (uint8_t)((CID_Tab[2] & 0x0000FF00) >> 8);
    cardinfo->SD_cid.ProdSN |= tmp << 16;

    // Byte 11 
    tmp = (uint8_t)(CID_Tab[2] & 0x000000FF);
    cardinfo->SD_cid.ProdSN |= tmp << 8;

    // Byte 12 
    tmp = (uint8_t)((CID_Tab[3] & 0xFF000000) >> 24);
    cardinfo->SD_cid.ProdSN |= tmp;

    // Byte 13 
    tmp = (uint8_t)((CID_Tab[3] & 0x00FF0000) >> 16);
    cardinfo->SD_cid.Reserved1 |= (tmp & 0xF0) >> 4;
    cardinfo->SD_cid.ManufactDate = (tmp & 0x0F) << 8;

    // Byte 14 
    tmp = (uint8_t)((CID_Tab[3] & 0x0000FF00) >> 8);
    cardinfo->SD_cid.ManufactDate |= tmp;

    // Byte 15 
    tmp = (uint8_t)(CID_Tab[3] & 0x000000FF);
    cardinfo->SD_cid.CID_CRC = (tmp & 0xFE) >> 1;
    cardinfo->SD_cid.Reserved2 = 1;

    return(errorstatus);
    }


FRESULT f_mount(FATFS* fs, const char * path, BYTE opt)
	{	
	UINT gdt;
	char disk[]= "S:\\";
	char name[100];

	if (SDCARD->Enabled != ENABLE) return FR_DENIED;		// carte non initialisee

	if (fs != NULL)		// mount
		{
		if (filesys != NULL) return FR_DENIED;				// un seul montage a la fois !!!
		
		disk[0]= path[0];

		int gdt= GetDiskType(disk);				// 0 si drive inexistant
		if (gdt == 0) return FR_DENIED;

		int gdv= GetDiskVolume(disk, name, sizeof(name));
		if (gdv)
			{
			if (strcmp(name, "SDcard") != 0) return FR_DENIED;		// access au RamDrive SD uniquement
			}
		else 
			return FR_DENIED;

		fs->mnt= 1;
		fs->drv= path[0];		// drive letter
		filesys= fs;
		}
	else				// unmount
		{
		if (filesys != NULL)
			{
			filesys->mnt= 0;
			filesys->drv= ' ';
			filesys= NULL;
			}
		}

	return FR_OK;
	}


FRESULT f_open(FIL* fp, const char * path, BYTE mode)
	{
	char acces[5]= "";
	FILE * f;

	if (filesys == NULL) return FR_DENIED;

	if (mode & FA_READ) strcat(acces, "r");
	if (mode & FA_WRITE) strcat(acces, "w");

	if ((mode & FA_CREATE_NEW) || (mode & FA_CREATE_ALWAYS)) strcat(acces, "+");
	
	strcat(acces, "t");			// text mode

	f= fopen(path, acces);

	if (f != NULL)	
		{
		fp->fptr= f;
		return FR_OK;
		}

	fp->fptr= NULL;
	return FR_INVALID_PARAMETER;
	}


int f_putc(TCHAR c, FIL* fp)
	{
	if (filesys == NULL) return EOF;

	return fputc(c, fp->fptr);
	}


char * f_gets(char * buff, int len, FIL* fp)
	{
	if (filesys == NULL) return NULL;

	char * cptr= fgets(buff, len, fp->fptr);

	return cptr;
	}

int f_puts(const char * str, FIL* fp)
	{
	if (filesys == NULL) return EOF;

	return fputs(str, fp->fptr);
	}


FRESULT f_read(FIL* fp, void* buff, UINT btr, UINT* br)
	{
	if (filesys == NULL) return FR_DENIED;

	if (br != NULL)	*br= (UINT) fread(buff, 1, btr, fp->fptr);
	}

FRESULT f_write(FIL* fp, void* buff, UINT btw, UINT* bw)
	{
	if (filesys == NULL) return FR_DENIED;

	if (bw != NULL)	*bw= (UINT) fwrite(buff, 1, btw, fp->fptr);
	}


#define f_printf(fp, str, ...) {if (filesys == NULL) return FR_DENIED; fprintf(fp->fptr, str, ...)}


FRESULT f_lseek(FIL* fp, DWORD ofs)
	{
	if (filesys == NULL) return FR_DENIED;

	int res= fseek(fp->fptr, ofs, 0);
	if (res == 0) return FR_OK;
	return FR_DENIED;
	}


FRESULT f_close(FIL* fp)
	{
	if (filesys == NULL) return FR_DENIED;

	if (fp->fptr != NULL)
		{
		fclose(fp->fptr);
		fp->fptr = NULL;
		return FR_OK;
		}

	return FR_INVALID_PARAMETER;
	}

FRESULT f_rename(const TCHAR* path_old, const TCHAR* path_new)
	{
	if (filesys == NULL) return FR_DENIED;

	int res= rename(path_old, path_new);
	if (res == 0) return FR_OK;
	return FR_DENIED;
	}

FRESULT f_unlink(const char * path)
	{
	if (filesys == NULL) return FR_DENIED;

	int res= remove(path);

	if (res == 0) return FR_OK;
	return FR_INVALID_PARAMETER;
	}


