/**
 * Virtual LCD Library for STM32F4xx devices (4 bits mode)
 */

#include "Lib_32f4.h"

#include "Lib_gpio.h"
#include "Lib_lcd.h"

#include "SimulArm.h"

extern Stm32F407 MyStm;

void delay_us(unsigned us);
void delay_ms(unsigned ms);

GPIO_TypeDef * GPIOp;

uint16_t Bit_Lcd_RS= 0;     // mode commande / data
uint16_t Bit_Lcd_E=  1;     // gestion du backlight (non operationnel ici)
uint16_t Bit_Lcd_D4= 4;     // 1e bit de donnees
uint16_t Bit_Lcd_D5= 5;     // 2e bit de donnees
uint16_t Bit_Lcd_D6= 6;     // 3e bit de donnees
uint16_t Bit_Lcd_D7= 7;     // 4e bit de donnees

// Initialisation du LCD
void LCD_Init(GPIO_TypeDef * GPIOx, uint16_t Hilo)
	{
   	// Port LCD en sortie
	GPIOp= GPIOx;

	if (Hilo == LOW)
		{
		Bit_Lcd_RS= 0;    
		Bit_Lcd_E=  1;   
		Bit_Lcd_D4= 4;   
		Bit_Lcd_D5= 5; 
		Bit_Lcd_D6= 6; 
		Bit_Lcd_D7= 7; 
		}
	else
		{
		Bit_Lcd_RS= 8;    
		Bit_Lcd_E=  9;   
		Bit_Lcd_D4= 12;   
		Bit_Lcd_D5= 13; 
		Bit_Lcd_D6= 14; 
		Bit_Lcd_D7= 15; 
		}

    LibGPIO_Conf(GPIOx, (1 << Bit_Lcd_D4) | (1 << Bit_Lcd_D5) | (1 << Bit_Lcd_D6) | (1 << Bit_Lcd_D7) | (1 << Bit_Lcd_RS ) | (1 << Bit_Lcd_E),
        GPIO_Mode_OUT, GPIO_OType_PP, GPIO_Speed_2MHz);

   	// Envoi des commandes de param�trage
	delay_ms(20);		// latence initiale de l'afficheur
	}


void delay_us(unsigned us)	  // delais en +/- �s
    {
    unsigned d= 10*us ;

	Lib_delay(d);
	}

void delay_ms(unsigned ms) 	  // delais en +/- ms
	{
	unsigned long d= 500*ms;

	Lib_delay(d);
	}


// Envoi commande
void LCD_SendCommand(char commande)
	{
	MyStm.Ports[GPIOp->Port_num].setOutput(Bit_Lcd_RS, 0);			// mode commande

	for (int i= 0 ; i < 4 ; i++)		// 4 bits de poids faible
		{
		if (commande & (1 << i))
   			MyStm.Ports[GPIOp->Port_num].setOutput(Bit_Lcd_D4+i, 1);	
		else
			MyStm.Ports[GPIOp->Port_num].setOutput(Bit_Lcd_D4+i, 0);	
		}
	MyStm.Update(GPIOp);

	for (int i= 0 ; i < 4 ; i++)		// 4 bits de poids fort
		{
		if (commande & (1 << (i+4)))
   			MyStm.Ports[GPIOp->Port_num].setOutput(Bit_Lcd_D4+i, 1);	
		else
			MyStm.Ports[GPIOp->Port_num].setOutput(Bit_Lcd_D4+i, 0);	
		}
	MyStm.Update(GPIOp);

	delay_ms(6);		// latence de l'afficheur
	}

// Envoi caractere
void LCD_SendChar(char caractere)
	{
	MyStm.Ports[GPIOp->Port_num].setOutput(Bit_Lcd_RS, 1);			// mode data

	for (int i= 0 ; i < 4 ; i++)		// 4 bits de poids faible
		{
		if (caractere & (1 << i))
   			MyStm.Ports[GPIOp->Port_num].setOutput(Bit_Lcd_D4+i, 1);	
		else
			MyStm.Ports[GPIOp->Port_num].setOutput(Bit_Lcd_D4+i, 0);	
		}
	MyStm.Update(GPIOp);

	for (int i= 0 ; i < 4 ; i++)		// 4 bits de poids fort
		{
		if (caractere & (1 << (i+4)))
   			MyStm.Ports[GPIOp->Port_num].setOutput(Bit_Lcd_D4+i, 1);	
		else
			MyStm.Ports[GPIOp->Port_num].setOutput(Bit_Lcd_D4+i, 0);	
		}
	MyStm.Update(GPIOp);

	delay_ms(6);		// latence de l'afficheur
	}

// Efface le contenu de l'ecran LCD
void LCD_Erase(void)
	{
   	LCD_SendCommand(LCD_CMD_ERASE);
	}

// Renvoie le curseur � la position initiale
void LCD_Home(void)
	{
   	LCD_SendCommand(LCD_CMD_HOME);
	}

// Configuration affichage LCD
void LCD_Blink(int e)
	{
	if (e) LCD_SendCommand(LCD_CMD_BLINK);
	else LCD_SendCommand(LCD_CMD_NOBLK);
	}

// Ecriture d'une cha�ne de caract�re sur le LCD
void LCD_Write(char * chaine)
	{
   	int i;

   	if (chaine == NULL)		// Si le pointeur pass� en param�tre n'est pas valide
      	return;      		// => sortie de la fonction

   	for (i= 0 ; i < strlen(chaine) ; i++)
      	LCD_SendChar(chaine[i]);
	}

// D�placement du curseur
void LCD_MoveCursor(int y, int x)
	{
   	int adresse;

   	if ((y < 1) || (y > 4) || (x < 1) || (x > 20))
      	return;	

   	LCD_SendCommand(0x80 + ((x-1) << 2) + (y-1));
	}

// Affiche une variale de type entier sur l'�cran LCD
void LCD_ShowInt(int entier)
	{
   	int compteur = 0;
   	char caracteres[10];  // Un entier comporte un maximum de 10 digits

   	// Si l'entier vaut 0, on l'affiche tout de suite
   	if(entier == 0)
   		{
      	LCD_SendChar('0');
   		}
   	else
   		{
      	// Gestion de l'affichage du signe moins dans le cas d'un nombre n�gatif
      	if(entier < 0)
      		{
        	LCD_SendChar('-');
        	entier = -entier;   // Repassage du nombre en positif
      		}

      	// Construction de la cha�ne de caract�res correspondante
      	// Principe: divisions successives par 10 pour r�cup�rer chaque digit
      	// jusqu'� arriver � 0.
      	while(entier>0 && compteur <= 10)
      		{
        	caracteres[compteur] = entier % 10;  // R�cup�ration du digit actuel
        	entier /= 10;   // Passage au digit suivant
        	compteur++;
      		}

      	// Affichage de la cha�ne (on commence par les derniers digit
      	// puisque la construction s'est faites dans le sens inverse)
      	for(;compteur>0; compteur--)
      		{
        	LCD_SendChar('0' + caracteres[compteur-1]);
      		}
   		}
	}

// Affiche une variable de type double � l'�cran avec un nombre de d�cimales d�fini
void LCD_ShowDouble(double vdouble, int nb_decimales)
	{
   	unsigned long fraction;
   	unsigned long fraction_successives;
   	unsigned long multiple = 1;
   	int nb_decimales_affichees = nb_decimales - 1;

   	// Etape 1 : Affichage de la valeur enti�re
   	LCD_ShowInt((int) vdouble);

   	// Etape 2 : Affichage de la partie d�cimale
   	// Principe : Multiplication successive par 10 pour construire le nombre entier
   	// correspondant aux d�cimales

   	if (nb_decimales > 0)
   		{
      	// Affichage de la virgule
      	LCD_SendChar(',');

      	// R�cup�ration du premier diviseur
      	while(nb_decimales--)
      		{
        	multiple *= 10;
      		}

      	// Toute la partie d�cimale est transform�e en partie enti�re
      	// Nombre positif
      	if (vdouble >= 0)
      		{
        	fraction = (vdouble - (int) vdouble) * multiple;
      		}
      	// Nombre n�gatif
      	else
      		{
        	fraction = ((int) vdouble - vdouble) * multiple;
      		}

      	fraction_successives = fraction;

      	// V�rification si besoin de rajouter des z�ros apr�s la virgule
      	// avant d'afficher la partie d�cimale
      	while(fraction_successives /= 10)
      		{
        	nb_decimales_affichees--;
      		}

      	// Affichage des z�ros si besoin
      	while(nb_decimales_affichees--)
      		{
        	LCD_SendChar('0');
      		}

      	// Affichage de la partie d�cimale
      	LCD_ShowInt((int) fraction);
   		}
	}
