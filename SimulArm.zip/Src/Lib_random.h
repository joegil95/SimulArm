/**
 * @(#) JG, 2025
 */

#include "Lib_32f4.h"

#include <stdlib.h>
#include <time.h>

/**
 * @brief  Initializes Random generator
 * @param  None
 * @retval None
 */
void LibRandom_Init(void);

/**
 * @brief  De initializes Random generator
 * @param  None
 * @retval None
 */
void LibRandom_DeInit(void);

/**
 * @brief  Gets 32-bit random number
 * @param  None
 * @retval 32-bit random number
 */
uint32_t LibRandom_Get(void);


