/************************************************************************************
 *  File:     main.c
 *  Purpose:  Cortex-M4 main file.
 ************************************************************************************/

#include "Lib_32f4.h"

#include "Lib_Gpio.h"
#include "Lib_Remote.h"

/// Telecommande (Protocole NEC)
/// connecter le r�cepteur infrarouge sur PD0
/// a configurer en entree sans resistance de pull

/*
Codes renvoyes par la telecommande:
0xF30C		= 0;
0xEF10		= 1;
0xEE11		= 2;
0xED12		= 3;
0xEB14		= 4;
0xEA15		= 5;
0xE916		= 6;
0xE718		= 7;
0xE619		= 8;
0xE51A		= 9;
*/

//	long duree[32];

/// Mesure de durees d'impulsions a 0 ou 1
long pulseIn(int pin, int state)
    {
    long d= 0;

    if (state)  // High
        {
        while(GPIO_ReadInputData(GPIOD) & (1 << pin))
            d++;
        }
    else        // Low
        {
        while(~GPIO_ReadInputData(GPIOD) & (1 << pin))
            d++;
        }

    return d;
    }


/// Protocole NEC
/// Attention : signal a 1 au repos
/// La t�l�commande envoie un prefixe constant sur 16 bits
/// puis un code variable sur 16 bits = 8 bits + complements
uint32_t Get_IRframe()
    {
    long p= 0;
    uint16_t prefix= 0;
    static uint16_t code= 0;            // static pour les repetitions
    long starting= 0;

    // Attente impulsions de debut de trame
    while(GPIO_ReadInputData(GPIOD) & (1 << IR_PIN));
	pulseIn(IR_PIN, 0);                 // 9 ms burst
    starting= pulseIn(IR_PIN, 1);       // start of frame 2,25 ou 4,5 ms

    if (starting > BIT_S)           // nouvelle touche
        {
        code= 0;

        for (int i = 0; i < IR_LENGTH/2; i++)       // capture du prefixe (LSB= ~MSB)
            {
			pulseIn(IR_PIN, 0);
            p= pulseIn(IR_PIN, 1);

		//	duree[i]= p;        // pour debug
            if (p >= BIT_1)
                prefix |= (1 << i);
            }

        for (int i = 0; i < IR_LENGTH/2; i++)       // capture du code (LSB= ~MSB)
            {
            pulseIn(IR_PIN, 0);
            p= pulseIn(IR_PIN, 1);

		//	duree[i+16]= p;        // pour debug
            if (p >= BIT_1)
                code |= (1 << i);
            }

        pulseIn(IR_PIN, 0);     // attente fin de trame

        return (code);
        }

    else                // repetition de touche
        {
        pulseIn(IR_PIN, 0);             // attente fin de trame
        return (code | (1 << 16));
        }
    }

