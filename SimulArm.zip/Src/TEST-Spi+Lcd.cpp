/************************************************************************************
 *  File:     main.c
 *  Purpose:  Cortex-M4 main file.
 ************************************************************************************/

#include "Lib_32f4.h"

#include "Lib_gpio.h"
#include "Lib_spi.h"


/// Connecter l'afficheur LCD sur SPI2

// Tableau des codes LCD
const uint16_t codes_LCD[] = {0xF6, 0x90, 0x75, 0xF1, 0x93, 0xE3, 0xE7, 0xB0, 0xF7, 0xF3};

// Tableau des valeurs a afficher
char udcm[4]= {0, 0, 0, 0};


void main()
    {
	int x= 1234;

    /// initialisation du SPI2 en mode 8 bits avec predivision 256
    LibSPI_Init(SPI2, LibSPI_DataSize_8b, SPI_BaudRatePrescaler_256);

    while(True)
        {
		udcm[0]= x % 10;
        udcm[1]= (x / 10) % 10;
        udcm[2]= (x / 100) % 10;
        udcm[3]= x / 1000;

		LibSPI_Send(SPI2, codes_LCD[udcm[0]]);
		LibSPI_Send(SPI2, codes_LCD[udcm[1]]);
		LibSPI_Send(SPI2, codes_LCD[udcm[2]]);
		LibSPI_Send(SPI2, codes_LCD[udcm[3]]);
	
		Lib_delay(1000);
        }
    }

