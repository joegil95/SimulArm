/************************************************************************************
 *
 * Test I2C avec horloge DS1307 virtuelle
 *
 ************************************************************************************/

#include "Lib_32f4.h"

#include "Lib_gpio.h"
#include "Lib_i2c.h"
#include "Lib_spi.h"


/// Connecter une Horloge I2C DS1307 sur I2C1 / Adresse 0x68

/// Connecter l'afficheur LCD sur SPI2

/// Slave address
#define DS1307        0x68

uint16_t codes_LCD[]= {0xF6, 0x90, 0x75, 0xF1, 0x93, 0xE3, 0xE7, 0xB0, 0xF7, 0xF3};


int main(void)
    {
    uint8_t hh, mm, ss;

    /// initialisation I2C1 a 100 kHz
    LibI2C_MasterInit(I2C1, 100000);

    /// initialisation du SPI2 en mode 8 bits avec predivision 256
    LibSPI_Init(SPI2, LibSPI_DataSize_8b, SPI_BaudRatePrescaler_256);

    /// initialisation de l'horloge si n�cessaire
	/// mais ici l'horloge virtuelle est tiree de l'horloge systeme du PC
/*
    LibI2C_SetReg(I2C1, DS1307, 0, DecToBcd(30));
    LibI2C_SetReg(I2C1, DS1307, 1, DecToBcd(25));
    LibI2C_SetReg(I2C1, DS1307, 2, DecToBcd(12));

    LibI2C_SetReg(I2C1, DS1307, 3, DecToBcd(1));
    LibI2C_SetReg(I2C1, DS1307, 4, DecToBcd(1));
    LibI2C_SetReg(I2C1, DS1307, 5, DecToBcd(1));
    LibI2C_SetReg(I2C1, DS1307, 6, DecToBcd(16));
*/

    while(True)
        {
		// recuperation heures + Minutes + secondes
        ss= BcdToDec(LibI2C_GetReg(I2C1, DS1307, 0));
        mm= BcdToDec(LibI2C_GetReg(I2C1, DS1307, 1));
        hh= BcdToDec(LibI2C_GetReg(I2C1, DS1307, 2));

		// afficher heures + minutes
		LibSPI_Send(SPI2, codes_LCD[mm%10]);
		LibSPI_Send(SPI2, codes_LCD[mm/10]+0x08);
		LibSPI_Send(SPI2, codes_LCD[hh%10]);
		LibSPI_Send(SPI2, codes_LCD[hh/10]);

		Lib_delay(100000);
        }
    }

