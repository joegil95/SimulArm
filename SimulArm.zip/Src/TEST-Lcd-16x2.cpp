/************************************************************************************
 *  File:     main.c
 *  Purpose:  Cortex-M4 main file.
 ************************************************************************************/


#include "Lib_32f4.h"

#include "Lib_gpio.h"
#include "Lib_lcd.h"


/// Connecter l'afficheur LCD sur le Port D Low (mode 4 bits)

void main(void)
	{
	int x= 0;

   	LCD_Init(GPIOD, LOW);	   // Initialisation du LCD
   	LCD_Erase();			// Effacement �cran

   	// Affichage d'une chaine
   	LCD_Write("Hello !");
	LCD_Blink(1);
	Lib_delay(10000000);
	LCD_Blink(0);

	// passage sur 2e ligne
   	LCD_MoveCursor(2,1);	
   	LCD_ShowInt(0);



   	while(True)
   		{
		LCD_MoveCursor(2,1);	
   		LCD_ShowInt(x);
		x++;

		Lib_delay(100000);
   		}
	}
