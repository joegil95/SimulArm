/**
 * Copyright (C) JG 2025
 */

#include "lib_buzzer.h"

void LibBuzzer_Output(uint16_t freq, uint32_t time)
	{
	Beep(freq, time);
	}