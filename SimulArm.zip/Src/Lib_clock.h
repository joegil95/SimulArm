/**
 * RTC virtual Clock Library for STM32F4xx devices
 */

#include "Lib_32f4.h"

#include "Lib_interrupts.h"


// RTC Clock sources
#define CLOCK_SOURCE_LSI    0       // Internal clock source
#define CLOCK_SOURCE_LSE    1       // External clock source

// RTC Init modes
#define CLOCK_CHECK   0       // check if init needed
#define CLOCK_FORCE   1       // init clock anyway

#define RTC_Format_BIN                    ((uint32_t)0x000000000)
#define RTC_Format_BCD                    ((uint32_t)0x000000001)

/* Days coded in BCD format */
#define RTC_Weekday_Monday             ((uint8_t)0x01)
#define RTC_Weekday_Tuesday            ((uint8_t)0x02)
#define RTC_Weekday_Wednesday          ((uint8_t)0x03)
#define RTC_Weekday_Thursday           ((uint8_t)0x04)
#define RTC_Weekday_Friday             ((uint8_t)0x05)
#define RTC_Weekday_Saturday           ((uint8_t)0x06)
#define RTC_Weekday_Sunday             ((uint8_t)0x07)

/* Months coded in BCD format */
#define RTC_Month_January              ((uint8_t)0x01)
#define RTC_Month_February             ((uint8_t)0x02)
#define RTC_Month_March                ((uint8_t)0x03)
#define RTC_Month_April                ((uint8_t)0x04)
#define RTC_Month_May                  ((uint8_t)0x05)
#define RTC_Month_June                 ((uint8_t)0x06)
#define RTC_Month_July                 ((uint8_t)0x07)
#define RTC_Month_August               ((uint8_t)0x08)
#define RTC_Month_September            ((uint8_t)0x09)
#define RTC_Month_October              ((uint8_t)0x10)
#define RTC_Month_November             ((uint8_t)0x11)
#define RTC_Month_December             ((uint8_t)0x12)

#define RTC_H12_AM                     ((uint8_t)0x00)
#define RTC_H12_PM                     ((uint8_t)0x40)

#define RTC_Alarm_A                       ((uint32_t)0x00000100)
#define RTC_Alarm_B                       ((uint32_t)0x00000200)

#define RTC_AlarmDateWeekDaySel_Date      ((uint32_t)0x00000000)
#define RTC_AlarmDateWeekDaySel_WeekDay   ((uint32_t)0x40000000)

#define RTC_AlarmMask_None                ((uint32_t)0x00000000)
#define RTC_AlarmMask_DateWeekDay         ((uint32_t)0x80000000)
#define RTC_AlarmMask_Hours               ((uint32_t)0x00800000)
#define RTC_AlarmMask_Minutes             ((uint32_t)0x00008000)
#define RTC_AlarmMask_Seconds             ((uint32_t)0x00000080)
#define RTC_AlarmMask_All                 ((uint32_t)0x80808080)

// global variables
extern uint8_t LibClock_AlarmA;
extern uint8_t LibClock_AlarmB;

// function prototypes
void LibClock_Init(uint16_t clock, RTC_DateTypeDef * RTC_DateStruct, RTC_TimeTypeDef * RTC_TimeStruct, uint16_t flag);
void LibClock_GetTime(RTC_TimeTypeDef * RTC_TimeStruct);
void LibClock_SetTime(RTC_TimeTypeDef * RTC_TimeStruct);
void LibClock_GetDate(RTC_DateTypeDef * RTC_DateStruct);
void LibClock_SetDate(RTC_DateTypeDef * RTC_DateStruct);
void LibClock_GetAlarm(uint32_t RTC_Alarm, RTC_AlarmTypeDef * RTC_AlarmStruct);
void LibClock_SetAlarm(uint32_t RTC_Alarm, RTC_AlarmTypeDef * RTC_AlarmStruct);
void LibClock_CmdAlarm(uint32_t RTC_Alarm, FunctionalState state);
uint8_t LibClock_OnAlarm(uint32_t RTC_Alarm);
uint8_t DecToBcd(uint8_t c);
uint8_t BcdToDec(uint8_t c);

// internal functions
void RTC_GetTime(uint32_t RTC_Format, RTC_TimeTypeDef * RTC_TimeStruct);
void RTC_GetDate(uint32_t RTC_Format, RTC_DateTypeDef * RTC_DateStruct);

void RTC_SetTime(uint32_t RTC_Format, RTC_TimeTypeDef * RTC_TimeStruct);
void RTC_SetDate(uint32_t RTC_Format, RTC_DateTypeDef * RTC_DateStruct);

void RTC_AlarmCmd(uint32_t RTC_Alarm, FunctionalState state);


