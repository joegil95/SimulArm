/************************************************************************************
 *  File:     main.c
 *  Purpose:  Cortex-M4 main file.
 ************************************************************************************/

#include "Lib_32f4.h"

/// Telecommande (Protocole NEC)
/// connecter le r�cepteur infrarouge sur PD0

#define IR_PIN        0         // IR Sensor pin
#define IR_LENGTH     32        // Number of bits sent by IR remote

/// valeurs a regler par tatonnement
#define BIT_S       120000	// Start bit min duration 
#define BIT_0       20000	// Binary 0 min duration
#define BIT_1       65000	// Binary 1 min duration

/*
Codes renvoyes par la telecommande:
0xF30C		= 0;
0xEF10		= 1;
0xEE11		= 2;
0xED12		= 3;
0xEB14		= 4;
0xEA15		= 5;
0xE916		= 6;
0xE718		= 7;
0xE619		= 8;
0xE51A		= 9;
*/

//	long duree[32];

/// Mesure de durees d'impulsions a 0 ou 1
long pulseIn(int pin, int state);


/// Protocole NEC
/// Attention : signal a 1 au repos
/// La t�l�commande envoie un prefixe constant sur 16 bits
/// puis un code variable sur 16 bits = 8 bits + complements
uint32_t Get_IRframe();

