/************************************************************************************
 *
 * Test afficheur 7 segments
 *
 ************************************************************************************/

#include "Lib_32f4.h"

#include "Lib_Gpio.h"

/// Connecter Afficheur 7 segments sur PG

/// Codes a envoyer a l'afficheur pour obtenir des chiffres
const uint16_t codes_7_seg[] = {0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x6F};


void main()
    {
    int count= 0;

	/// configuration des ports
	/// la broche 8 permet de s�lectionner le c�t� d'affichage (Un seul � la fois)
    LibGPIO_Conf(GPIOG, GPIO_Pin_Low | GPIO_Pin_8, GPIO_Mode_OUT, GPIO_OType_PP, GPIO_Speed_2MHz);

    while(True)
        {
		/// l'afficheur fonctionne en logique inverse (Anodes communes)
		if (count < 10) GPIO_Write(GPIOG, ~codes_7_seg[count]);
		else GPIO_Write(GPIOG, ~(codes_7_seg[count-10] | (1 << 8)));

		/// pour afficher sur deux chiffres, utiliser un multiplexage temporel avec interruptions !

		count++;
		if (count > 19) count= 0;

		Lib_delay(300000);
        }
    }

