/**
 * Copyright (C) JG 2016
 */


#include "Lib_32f4.h"

#include "Lib_gpio.h"
#include "Lib_ps2.h"

#include "SimulArm.h"

extern EXTI_InitTypeDef * EXTI;

int16_t fullcode[10]= {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1};     // buffer clavier
GPIO_TypeDef * GPIO_port= GPIOC;
uint16_t GPIO_pin= (1 << 7);
int lock= 0;


 /**
  * @brief  Initialize external interrupt on PG9 (clock input)
  * @param  GPIOx = Data RX GPIO port (GPIOC or GPIOD)
  * @param  PINx = Data RX GPIO pin (0 to 15)
  * @retval None
  */
void LibPs2_Init(GPIO_TypeDef * GPIOx, uint16_t PINx)
    {
    // Data port and pin
    GPIO_port= GPIOx;
    GPIO_pin= (1 << PINx);

    // RX set as input with pull-up on GPIOx
	LibGPIO_Conf(GPIOx, GPIO_pin, GPIO_Mode_IN, GPIO_PuPd_UP, GPIO_Speed_50MHz);

	// Set pin 9 as clock input on GPIOG
	LibGPIO_Conf(GPIOG, GPIO_Pin_9, GPIO_Mode_IN, GPIO_PuPd_UP, GPIO_Speed_100MHz);	

	// Enables EXTI_Line9
	EXTI->EXTI_Lines |= EXTI_Line9;
	EXTI->Pending &= ~EXTI_Line9;
    }


 /**
  * @brief  Get last received Ps2 data
  * @param  None
  * @retval Ps2 data (8 bits) or -1 if none
  */
int16_t LibPs2_Get()
    {
    int retry= 0;	
    static int p= 0;
    int16_t code= -1;

    do
        {
        if (!lock)
            {
            code= fullcode[p];
            fullcode[p]= -1;   // data lue
            p++;
            if (p >= 10) p= 0;
            retry++;
            }
        }
    while ((code == -1) && (retry < 3));

    return code;
    }


// modifie fullcode si caract�re complet recu
void LibPs2_Receive(void)
    {
    static int state= START;
    static int16_t recu= 0;
    static int16_t code= -1;
    static int nb= 0, parity= 0;
    static int pos= 0;

    uint16_t bit= 0;

    // lecture data (sur PC7 par defaut)
    bit= GPIO_ReadInputData(GPIO_port) & GPIO_pin;
    code= -1;

    switch(state)
        {
        case START:             // bit de start (0)
            recu= 0; nb= 0; parity= 0;
            if (bit == 0)  // ok
                state= DATA;
            else                // erreur => RAZ
                state= START;

            break;

        case DATA:              //  bit de donnee
            if (bit != 0)
                {
                recu |= (1 << nb);
                parity++;
                }
            nb++;
            if (nb >= 8) state= PARITY;
            break;

        case PARITY:            // verification de la parite
            if (bit != 0)
                parity++;

            if (parity & (1 << 0))  // impair ?
                state= STOP;        // ok
            else
                state= START;       // erreur => RAZ
            break;

        case STOP:                  // bit de stop (1)
            if (bit != 0)      // ok
                code= recu;

            state= START;
            break;
        }

    if (code != -1)     // caractere complet si code != -1
        {
        lock= 1;    // verrouillage lecture

        fullcode[pos]= code;
        pos++;
        if (pos >= 10) pos= 0;

        lock= 0;
        }
    }


// routine d'interruption pour reception
void EXTI9_5_Handler(void)
    {
	if (EXTI_GetITStatus(EXTI_Line9) != RESET)
        {
        LibPs2_Receive();

        // Clear interrupt flag
		EXTI_ClearITPendingBit(EXTI_Line9);
        }
    }


ITStatus EXTI_GetITStatus(uint32_t EXTI_Line)
	{
	if (EXTI->EXTI_Lines & EXTI_Line) return 1;
	else return 0;
	}


void EXTI_ClearITPendingBit(uint32_t EXTI_Line)
	{
	EXTI->Pending &= ~EXTI_Line;
	}