/**
    Lecteur de carte SD en mode SDIO 4 bits � 24 MHz en mode POLLING

	NB: 
	Le programme necessite un Ramdisk S: de 64 MO en Fat32 Removable pour simuler la carte SD
	en utilisant le programme externe de creation de Ramdisk Softs\Ramdisk\Ramdiskc.exe
	de Softperfect, qui doit etre installe au prealable sous Windows

	Executer ce programme en pas a pas et voir ce qui se passe dans le lecteur S: en parallele
	Apres activation du peripherique SDCard en mode SDIO et insertion de la carte virtuelle
	puis lancement du programme
**/


/* Includes ------------------------------------------------------------------*/
#include "Lib_32f4.h"

#include "Lib_gpio.h"
#include "Lib_sdcard.h"

#include <string.h>

// tableau qui contient le CSD, CID, capacit�, type... apres initialisation
extern SD_CardInfo SDCardInfo;


int main(void)
    {
    char buffer[100]= "";
    TCHAR * eof;
    int nb= 0;

    SD_Error Status;

    FATFS FatFs;
    FRESULT fr;

    FIL f;

    /// Initialisation des horloges
    SystemInit();

    /// Initialisation SD card : doit retourner SD_OK
    Status= SD_Init();

	fr= f_mount(&FatFs, "S:", 1);     // montage fs
    if (fr == FR_OK)
		{
	    fr= f_open(&f, "S:Toto.txt", FA_CREATE_ALWAYS | FA_WRITE);
        if (fr == FR_OK)
            {
            // ecriture de lignes ds fichier (OK)
            nb= f_puts("Toto\n", &f2);
            nb= f_puts("Tata\n", &f2);
            nb= f_puts("Truc\n", &f2);
            }

        f_close(&f);

        // suppression du fichier (OK)
        fr= f_unlink("S:Toto.txt");
        }

    f_mount(0, "S:", 1);      // demontage fs

    while(True)
        {
        }
    }

