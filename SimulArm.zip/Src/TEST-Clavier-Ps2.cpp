/************************************************************************************
 *
 * Test du clavier (virtuel) en mode PS2 
 *
 ************************************************************************************/

#include "Lib_32f4.h"

#include "Lib_interrupts.h"

#include "Lib_gpio.h"
#include "Lib_ps2.h"
#include "Lib_glcd.h"

/// USRT en mode Reception synchrone / esclave
/// Utilisant une interruption externe pour la reception
/// Les USART du STM32F4 ne fonctionnent qu'en mode maitre
/// et ne sont en fait que des SPI am�lior�s

/// Connecter l'afficheur GLCD sur PF

/// Connecter TX du clavier ou autre sur PC7 (RX)
/// Connecter CLK du clavier ou autre sur PG9 (CLK)
/// Format = 8 bits, 1 stop, parite impaire
/// Clock fournie par le clavier


// definition des touches speciales (perso)
#define ALT  1
#define CTL  2
#define SHL  3
#define SHR  4
#define MAJ  5

#define BAK  8
#define TAB  9

#define RET 13

#define F01 14      // touches de fonctions
#define F02 15
#define F03 16
#define F04 17
#define F05 18
#define F06 19
#define F07 20
#define F08 21
#define F09 22
#define F10 23
#define F11 24
#define F12 25

#define ESC 27
#define SPC 32

#define APO 96      // Apostrophe
#define SCR 140
#define NUM 141


// mapping des scancodes en azerty simplifie
unsigned azerty1[]= {0, F09, 0, F05, F03, F01, F02, F12 ,0, F10, F08, F06, F04, TAB, '�', 0,
                 0, ALT, SHL, 0, CTL, 'a', '&', 0, 0, 0, 'w', 's', 'q', 'z', '~', 0,
                 0, 'c', 'x', 'd', 'e', APO, '"', 0, 0, SPC, 'v', 'f', 't', 'r', '(', 0,
                 0, 'n', 'b', 'h', 'g', 'y', '-', 0, 0, 0, ',', 'j', 'u', '�', '_', 0,
                 0, ';', 'k', 'i', 'o', '�', '�', 0, 0, ':', '!', 'l', 'm', 'p', ')', 0,
                 0, 0, '%', 0, '^', '=', 0, 0, MAJ, SHR, RET, '$', 0, '*', 0, 0,
                 0, '<', 0, 0, 0, 0, BAK, 0, 0, '1', 0, '4', '7', 0, 0, 0,
                 '0', '.', '2', '5', '6', '8', ESC, NUM, F11, '+', '3', '-', '*', '9', SCR, 0,
                 0, 0, 0, F07, 0, 0, 0, 0, 0, 0, 0, 0, 0 ,0, 0, 0};


void main()
    {
    int16_t scancode= -1;
    int16_t ext= 0, x= -1;
    unsigned key= 0;
    int maj= 0;

    GLCD_InitDisplay();
	GLCD_ClearScreen();

    GLCD_Move(0, 0, 0);
    GLCD_Write("Scancode:");

    GLCD_Move(0, 2, 0);
    GLCD_Write("Ascii:");

    GLCD_Move(1, 0, 0);
    GLCD_Write("Caractere:");

    LibPs2_Init(GPIOC, 7);

    /// NB:
    /// Les touches standard generent un code Make quand on appuie
    /// et le meme code preced� de 0xF0 lorsqu'on relache (Release)
    /// Certaines touches speciales generent 3 codes

	while(True)
        {
        ext= 0;
        x= -1;

        scancode= LibPs2_Get();
        if (scancode != -1)     // caractere recu
            {
            x= scancode;

            if (scancode == 0xF0) // release simple (2 codes)
                {
				while ((x= LibPs2_Get()) == -1);     // attendre scancode suivant

				key= azerty1[x];

                x= -1;
                }
		   	}

        if (x != -1)        // code make
            {
            key= azerty1[x];     // conversion azerty            

            GLCD_Move(0, 1, 0);
            GLCD_ShowInt(x);
            GLCD_Write("  ");

            GLCD_Move(0, 3, 0);
            GLCD_ShowInt(key);
            GLCD_Write("  ");

            GLCD_Move(1, 1, 0);
			GLCD_WriteChar(key);

            x= 0;
            }
        }
    }


