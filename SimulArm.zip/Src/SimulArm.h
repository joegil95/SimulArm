/*
SimulArm.cpp : Simulateur de �C STM32
*/

#include <afxwin.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>

#include <afxcmn.h>		// Pour les controles Slider (Trackbar)

#include "Lib_32f4.h"

#include "Lib_gpio.h"
#include "Lib_adc.h"
#include "Lib_spi.h"
#include "Lib_i2c.h"
#include "Lib_eeprom.h"

#include "Lib_timer.h"
#include "Lib_interrupts.h"

#include "SimulArm.rh"

#define STPORT_INP		0
#define STPORT_OUT		1

#define STPORT_PNO		0
#define STPORT_PUP		1
#define STPORT_PDN		2

#define ADCRES_LOW		8
#define ADCRES_MED		10
#define ADCRES_HIG		12

#define TIM_7SEG		100
#define TIM_POTS		200
#define TIM_DISP		300
#define TIM_LCD			400
#define TIM_RTC			500
#define TIM_ZAP1		600
#define TIM_ZAP2		601
#define TIM_KBRD		700
#define TIM_ROUE		800
#define TIM_DS13		900
#define TIM_PROM		1000

#define SDIO_IN			0x0001
#define SDIO_CON		0x0002

#define ETH_OFF			0x0000
#define ETH_ON			0x0001


UINT MyThreadProc(LPVOID pParam);


// Classe Port 16 bits
class StPort
	{
	private:// attributs
			int inp[16];			// int pour entr�es ADC
			int out[16];			// int pour sorties DAC
			int old[16];			// anciennes sorties
			char mode[16];			// entr�e / sortie
			char pull[16];			// pull-up, pull-dn ou nopull

	public:	// constructeur
			StPort();

			// methodes
			void setInput(int i, int in);
			int getInput(int i);
			void setOutput(int i, int out);
			int getOutput(int i);
			void setMode(int i, char mod);
			char getMode(int i);
			void setPull(int i, char pul);
			char getPull(int i);
			void setResol(int i, char res);
			char getResol(int i);	

			void resetPort();
			bool hasOutChanged();
	};


class Stm32F407
	{
	public:	// attributs
		StPort Ports[7];		// Ports A -> G
		RTC_TypeDef StRtc;		// Horloge RTC interne
		unsigned IRQ_Status;		// Interupts Enable / Disable
		unsigned SDIO_Status;		// Port SDIO
		unsigned ETH_Status;		// Port Ethernet
		
		// constructeur
		Stm32F407();

		// methodes
		void reset();
		void Update(GPIO_TypeDef * GPIOx);
		void Update(SPI_TypeDef * SPIx, uint16_t data);
		void Update(I2C_TypeDef * I2Cx, uint16_t adr, uint16_t cmd, void * data);
		void Update(TIM_TypeDef * TIMx);
		void Update(RTC_TypeDef * RTCx, UINT param);		
	};


// Classe derivee de CFrameWnd
class CSimulWnd : public CFrameWnd
	{
	public:	// attributs
            CMenu * menu;
   			CFont police;
			CBitmap bmp;
			CWinThread * tp;
			char Jeton[20];

			CSimulWnd(HICON);	// constructeur
            ~CSimulWnd();		// destructeur

			BOOL VerifyToken();

			afx_msg void OnPaint();				// procedures de messages
			afx_msg void OnTimer(UINT tid);
			afx_msg void OnUpdateMenu(CCmdUI * CmdUi);
			afx_msg void CMSaveCfg();
			afx_msg void CMLoadCfg();
			afx_msg void CMLoadCfg(BOOL full);
			afx_msg void CMStart();
			afx_msg void CMStop();
			afx_msg void CMToken();
			afx_msg void CMUser0(WPARAM wParam, LPARAM lParam);
			afx_msg void CMLeds();
			afx_msg void CMLeds(char Port, UINT Hilo, LONG left, LONG top);
			afx_msg void CMBps();
			afx_msg void CMBps(char Port, UINT Hilo, LONG left, LONG top);
			afx_msg void CMPots();
			afx_msg void CMPots(char Adc, UINT Canal, LONG left, LONG top);
			afx_msg void CM7Seg();
			afx_msg void CM7Seg(char Port, LONG left, LONG top);
			afx_msg void CMDisp();
			afx_msg void CMDisp(char Spi, LONG left, LONG top);
			afx_msg void CMKpad();
			afx_msg void CMKpad(char Port, UINT Hilo, LONG left, LONG top);
			afx_msg void CMLcd();
			afx_msg void CMLcd(char Port, UINT Hilo, LONG left, LONG top);
			afx_msg void CMGlcd();
			afx_msg void CMGlcd(char Port, LONG left, LONG top);
			afx_msg void CMRtc();
			afx_msg void CMRtc(LONG left, LONG top);
			afx_msg void CMZap();
			afx_msg void CMZap(char Port, UINT Hilo, LONG left, LONG top);
			afx_msg void CMKbrd();
			afx_msg void CMKbrd(char Port, UINT Hilo, LONG left, LONG top);
			afx_msg void CMRoue();
			afx_msg void CMRoue(char Port, UINT Hilo, LONG left, LONG top);
			afx_msg void CMDs13();
			afx_msg void CMDs13(char I2c, uint8_t adr, LONG left, LONG top);
			afx_msg void CMProm();
			afx_msg void CMProm(char Spi, char Port, LONG left, LONG top);
			afx_msg void CMSDcd();
			afx_msg void CMSDcd(char Spi, LONG left, LONG top);
			afx_msg void CMEth();
			afx_msg void CMEth(LONG left, LONG top);
			afx_msg void CMUart();

			afx_msg void CMAbout();
			afx_msg void CMQuit();
			afx_msg void OnClose();

			BOOL KillTimer(int tid);

			DECLARE_MESSAGE_MAP()	// table de messages
	};


// Classe pour saisie Token derivee de CDialog
class CToken : public CDialog
	{
	public:	int newtok, round;		// attributs
			char tok[100];
			
			CToken(int id);			// constructeur

            BOOL OnInitDialog();		// methodes

			afx_msg void OnOK();
			afx_msg void OnCancel();
			afx_msg void OnClose();
			afx_msg void PostNcDestroy();
			
   			DECLARE_MESSAGE_MAP()   // table de messages
   };

// Classe pour Leds derivee de CDialog
class CLeds : public CDialog
	{
	public:	HICON green, red, gray;		// attributs
			
			CLeds(int id);			// constructeur

            BOOL OnInitDialog();		// methodes

			afx_msg LRESULT OnPrint(WPARAM, LPARAM);
			afx_msg void OnClic(UINT id);
			afx_msg void OnOK();
			afx_msg void OnCancel();
			afx_msg void OnClose();
			afx_msg void PostNcDestroy();
			
			void reset();
			GPIO_TypeDef * getPort();
			UINT getHiLo();
			void setPort(char Port, UINT Hilo);

   			DECLARE_MESSAGE_MAP()   // table de messages
   };


// Classe pour boutons derivee de CDialog
class CBps : public CDialog
	{
	public:	CBps(int id);			// constructeur

            BOOL OnInitDialog();				// methodes
			BOOL PreTranslateMessage(MSG* Msg);		// a surcharger pour gestion fine des BP

			afx_msg void OnClic(UINT id);
			afx_msg void OnOK();
			afx_msg void OnCancel();
			afx_msg void OnClose();
			afx_msg void PostNcDestroy();

			void reset();
			GPIO_TypeDef * getPort();
			UINT getHilo();
			void setPort(char Port, UINT Hilo);

   			DECLARE_MESSAGE_MAP()   // table de messages
   };


// Classe pour potards derivee de CDialog
class CPots : public CDialog
	{
	public:	CSliderCtrl *Taskbar1;	// attributs
			CSliderCtrl *Taskbar2;
			CSliderCtrl *Taskbar3;
   			
            CPots(int id);			// constructeur

            BOOL OnInitDialog();		// methodes

			afx_msg void OnClic(UINT id);
			afx_msg void OnHScroll(UINT Code, UINT Pos, CScrollBar* ScrollBar);
			afx_msg void OnTimer(UINT tid);
			afx_msg void OnOK();
			afx_msg void OnCancel();
			afx_msg void OnClose();
			afx_msg void PostNcDestroy();

			void reset();
			ADC_TypeDef * getAdc();
			UINT getChannel(ADC_TypeDef * ADCx);
			void setAdc(char Adc, UINT Canal);

   			DECLARE_MESSAGE_MAP()   // table de messages
   };


// Classe pour afficheur 7 Segments derivee de CDialog
class C7Seg : public CDialog
	{
	public:	HICON green, gray;		// attributs
			long ticks, ltick, rtick;
			int old[16];
		
			C7Seg(int id);			// constructeur

            BOOL OnInitDialog();		// methodes

			afx_msg LRESULT OnPrint(WPARAM, LPARAM);
			afx_msg void OnTimer(UINT tid);
			afx_msg void OnClic(UINT id);
			afx_msg void OnOK();
			afx_msg void OnCancel();
			afx_msg void OnClose();
			afx_msg void PostNcDestroy();

			void reset();
			GPIO_TypeDef * getPort();
			void setPort(char Port);

   			DECLARE_MESSAGE_MAP()   // table de messages
   };


// Classe pour afficheur LCD sur SPI derivee de CDialog
class CDisp : public CDialog
	{
	public:	SPI_TypeDef * lastSpi;		// attributs
			unsigned short cods[4];
			unsigned short olds[4];
			unsigned cnt;
			HICON black, gray;

			CDisp(int id);			// constructeur

            BOOL OnInitDialog();		// methodes

			afx_msg LRESULT OnPrint(WPARAM, LPARAM);
			afx_msg void OnTimer(UINT tid);
			afx_msg void OnClic(UINT id);
			afx_msg void OnOK();
			afx_msg void OnCancel();
			afx_msg void OnClose();
			afx_msg void PostNcDestroy();

			void Print(SPI_TypeDef * SPIx, BOOL force);
			void reset();
			SPI_TypeDef * getSpi();
			void setSpi(char Spi);

   			DECLARE_MESSAGE_MAP()   // table de messages
   };


// Classe pour pave numerique 3x4 derivee de CDialog
class CKpad : public CDialog
	{
	public:	char buffer;		// attributs
			int state[12];
		
			CKpad(int id);			// constructeur

            BOOL OnInitDialog();		// methodes
			BOOL PreTranslateMessage(MSG* Msg);		// a surcharger pour gestion fine des BP

			afx_msg void OnClic(UINT id);
			afx_msg void OnOK();
			afx_msg void OnCancel();
			afx_msg void OnClose();
			afx_msg void PostNcDestroy();

			void reset();
			GPIO_TypeDef * getPort();
			UINT getHilo();
			void setPort(char Port, UINT Hilo);

   			DECLARE_MESSAGE_MAP()   // table de messages
   };


// Classe pour afficheur LCD 16x2 derivee de CDialog
class CLcd : public CDialog
	{
	public:	char line[4*20];		// attributs
			int posx, posy;
			BOOL poids;
			char chr;
			BOOL blink;
			CFont police;
		
			CLcd(int id);			// constructeur

            BOOL OnInitDialog();		// methodes

			afx_msg LRESULT OnPrint(WPARAM, LPARAM);
			afx_msg void OnClic(UINT id);
			afx_msg void OnTimer(UINT tid);
			afx_msg void OnOK();
			afx_msg void OnCancel();
			afx_msg void OnClose();
			afx_msg void PostNcDestroy();
			afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd *pWnd, UINT nCtlColor);

			void reset(int v);
			GPIO_TypeDef * getPort();
			UINT getHilo();
			void setPort(char Port, UINT Hilo);

   			DECLARE_MESSAGE_MAP()   // table de messages
   };


// Classe pour afficheur GLCD 64x128 derivee de CDialog
class CGlcd : public CDialog
	{
	public:	unsigned char octet[2][8][64];		// attributs
			bool pageChanged[2][8];
			bool on;
			unsigned char side, page, col;
			char chr;
			CFont police;
			CBitmap screen;
		
			CGlcd(int id);			// constructeur

            BOOL OnInitDialog();		// methodes

			afx_msg void OnPaint();	
			afx_msg LRESULT OnPrint(WPARAM, LPARAM);
			afx_msg void OnClic(UINT id);
			afx_msg void OnOK();
			afx_msg void OnCancel();
			afx_msg void OnClose();
			afx_msg void PostNcDestroy();

			void reset();
			GPIO_TypeDef * getPort();
			void setPort(char Port);

   			DECLARE_MESSAGE_MAP()   // table de messages
   };


// Classe pour horloge RTC derivee de CDialog
class CRtc : public CDialog
	{
	public:	char line[2*20];		// attributs
			CFont police;
			int Th, Tm, Ts;
			int Da, Dm, Dj, Dd;
			int wait;
		
			CRtc(int id);			// constructeur

            BOOL OnInitDialog();		// methodes

			afx_msg LRESULT OnPrint(WPARAM, LPARAM);
			afx_msg void OnTimer(UINT tid);
			afx_msg void OnOK();
			afx_msg void OnCancel();
			afx_msg void OnClose();
			afx_msg void PostNcDestroy();

			void reset();
			int8_t DecToBcd(uint8_t c);
			uint8_t BcdToDec(uint8_t c);
			bool TimeComp(RTC_AlarmTypeDef * RTC_Alarm);

   			DECLARE_MESSAGE_MAP()   // table de messages
   };


// Classe pour afficheur LCD sur SPI derivee de CDialog
class CZap : public CDialog
	{
	public:	int32_t buffer, last;		// attributs
			int state[25];			// 25 touches maxi
			int8_t ready, repeat, again;
			int8_t nbit;
		
			CZap(int id);			// constructeur

            BOOL OnInitDialog();		// methodes
			BOOL PreTranslateMessage(MSG* Msg);		// a surcharger pour gestion fine des BP

			afx_msg void OnTimer(UINT tid);
			afx_msg void OnClic(UINT id);
			afx_msg void OnOK();
			afx_msg void OnCancel();
			afx_msg void OnClose();
			afx_msg void PostNcDestroy();

			void reset();
			GPIO_TypeDef * getPort();
			UINT getHilo();
			void setPort(char Port, UINT Hilo);

   			DECLARE_MESSAGE_MAP()   // table de messages
   };


// Classe pour clavier PC derivee de CDialog
class CKbrd : public CDialog
	{
	public:	char line[4*20];		// attributs
			char buffer[16];		// tampon
			char oldmake;
			char chr;
			char pos;
			int8_t nbit;

			CFont police;
		
			CKbrd(int id);			// constructeur

            BOOL OnInitDialog();				// methodes
			BOOL PreTranslateMessage(MSG* Msg);

			afx_msg void OnClic(UINT id);
			afx_msg void OnTimer(UINT tid);
			afx_msg void OnChar(UINT Chr, UINT RepCnt, UINT Flags);			
			afx_msg void OnOK();
			afx_msg void OnCancel();
			afx_msg void OnClose();
			afx_msg void PostNcDestroy();
			afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd *pWnd, UINT nCtlColor);

			void reset();
			void OnKey(UINT Chr, UINT Scan, UINT UpDn);
			GPIO_TypeDef * getPort();
			UINT getHilo();
			void setPort(char Port, UINT Hilo);

   			DECLARE_MESSAGE_MAP()   // table de messages
   };


// Classe pour Roue codeuse derivee de CDialog
class CRoue : public CDialog
	{
	public:	int8_t num, oldnum;			// attributs
			int8_t offset;
			BOOL timon;

			CFont police;
		
			CRoue(int id);			// constructeur

            BOOL OnInitDialog();				// methodes

			afx_msg void OnClic(UINT id);
			afx_msg void OnTimer(UINT tid);
			afx_msg void OnOK();
			afx_msg void OnCancel();
			afx_msg void OnClose();
			afx_msg void PostNcDestroy();

			void reset();
			GPIO_TypeDef * getPort();
			UINT getHilo();
			void setPort(char Port, UINT Hilo);

   			DECLARE_MESSAGE_MAP()   // table de messages
   };


// Classe pour horloge RTC derivee de CDialog
class CDs13 : public CDialog
	{
	public:	char line[2*20];		// attributs
			CFont police;
			int Th, Tm, Ts;
			int Da, Dm, Dj, Dd;
			int wait;
			uint16_t I2c_State;		// etat courant
			int8_t I2c_Reg;			// registre courant
			int * Regs[7];			// registres I2C
		
			CDs13(int id);			// constructeur

            BOOL OnInitDialog();		// methodes

			afx_msg LRESULT OnPrint(WPARAM, LPARAM);
			afx_msg void OnTimer(UINT tid);
			afx_msg void OnClic(UINT id);
			afx_msg void OnOK();
			afx_msg void OnCancel();
			afx_msg void OnClose();
			afx_msg void PostNcDestroy();

			void reset();
			I2C_TypeDef * getI2c();
			uint8_t getAddress();
			void setI2c(char I2c, uint8_t adr);
			int8_t DecToBcd(uint8_t c);
			uint8_t BcdToDec(uint8_t c);

   			DECLARE_MESSAGE_MAP()   // table de messages
   };


// Classe pour EEprom AMD derivee de CDialog
class CProm : public CDialog
	{
	public:	char line[2*20];		// attributs
			unsigned char Memory[8192];
			uint16_t Mem_Adr, Mem_Tmp; 
			bool Prom_Ready, Timer;
			CFont police;
		
			CProm(int id);			// constructeur

            BOOL OnInitDialog();		// methodes

			afx_msg LRESULT OnPrint(WPARAM, LPARAM);
			afx_msg void OnTimer(UINT tid);
			afx_msg void OnClic(UINT id);
			afx_msg void OnOK();
			afx_msg void OnCancel();
			afx_msg void OnClose();
			afx_msg void PostNcDestroy();
			afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd *pWnd, UINT nCtlColor);

			void reset();
			GPIO_TypeDef * getPort();
			SPI_TypeDef * getSpi();
			void setPort(char Port);
			void setSpi(char Spi);

   			DECLARE_MESSAGE_MAP()   // table de messages
   };


// Classe pour SD Card derivee de CDialog
class CSDcd : public CDialog
	{
	public:							// attributs
			CFont police;
		
			CSDcd(int id);			// constructeur

            BOOL OnInitDialog();		// methodes

			afx_msg LRESULT OnPrint(WPARAM, LPARAM);
			afx_msg void OnClic(UINT id);
			afx_msg void OnOK();
			afx_msg void OnCancel();
			afx_msg void OnClose();
			afx_msg void PostNcDestroy();

			void reset();
			SPI_TypeDef * getSpi();
			void setSpi(char Spi);

   			DECLARE_MESSAGE_MAP()   // table de messages
   };


// Classe pour Interface Ethernet derivee de CDialog
class CEth : public CDialog
	{
	public:	CFont police;			// attributs
					
			CEth(int id);			// constructeur

            BOOL OnInitDialog();		// methodes

			afx_msg void OnClic(UINT id);
			afx_msg void OnOK();
			afx_msg void OnCancel();
			afx_msg void OnClose();
			afx_msg void PostNcDestroy();
			afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd *pWnd, UINT nCtlColor);

			void reset();
			int GetMacAddress(char * address);
			int GetIpAddress(char * address);
			UINT getHilo();

   			DECLARE_MESSAGE_MAP()   // table de messages
   };


// Classe derivee de CWinApp
class CSimulApp : public CWinApp
	{
	public:	virtual BOOL InitInstance();
   			virtual int ExitInstance();
	};