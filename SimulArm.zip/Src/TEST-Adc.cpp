/************************************************************************************
 *
 * Test de l'ADC (qui genere des valeurs avec des fluctuations comme dans la realite)
 *
 ************************************************************************************/

#include "Lib_32f4.h"

#include "Lib_gpio.h"
#include "Lib_adc.h"

/// Connecter 8 leds sur PD0 � PD7
/// Connecter un potentiometre sur ADC1 Canal 4


void main()
    {
    /// configuration des ports
    LibGPIO_Conf(GPIOD, GPIO_Pin_Low, GPIO_Mode_OUT, GPIO_OType_PP, GPIO_Speed_2MHz);

    /// initialisation ADC1 canal 4 resolution 8 bits
    LibADC_Init(ADC1, ADC_Channel_4, ADC_Resolution_8b);

    while(True)
        {
        int val= 0;

        val= LibADC_Read(ADC1, ADC_Channel_4);   // acquisition

		/// ecrit la valeur en binaire sur les leds
        GPIO_Write(GPIOD, val);
        }
    }

