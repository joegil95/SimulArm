/*
 * Virtual Keypad 3 x 4 Library for STM32F4xx devices
 */

#include "Lib_32f4.h"

#include "Lib_gpio.h"

#define LOW		0x0001
#define HIGH	0x0100

// initialisation des ports pour le clavier
void LibKeypad_Init(GPIO_TypeDef* GPIOx, uint16_t Hilo);

// lecture d'une touche au clavier
// retourne -1 si RAS
int8_t LibKeypad_Get(GPIO_TypeDef* GPIOx);

