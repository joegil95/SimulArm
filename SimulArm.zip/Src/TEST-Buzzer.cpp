/************************************************************************************
 *
 * Test du buzzer
 *
 ************************************************************************************/

#include "Lib_32f4.h"

#include "Lib_gpio.h"
#include "Lib_buzzer.h"

/// Connecter 1 bouton poussoir sur PD0


void main()
    {
    /// configuration des ports
    LibGPIO_Conf(GPIOD, GPIO_Pin_0, GPIO_Mode_IN, GPIO_PuPd_NOPULL, GPIO_Speed_2MHz);

    while(True)
        {
        uint16_t x;
		
		/// appuyer sur le bouton pour activer le buzzer
		x= ~GPIO_ReadInputData(GPIOD);

		if (x & (1 << 0)) LibBuzzer_Output(2000, 1000);

		Lib_delay(100000);
        }
    }

