/************************************************************************************
 *
 * Test d'un Timer et des interruptions associees
 *
 ************************************************************************************/

#include "Lib_32f4.h"

#include "Lib_gpio.h"
#include "Lib_timer.h"

#include "Lib_interrupts.h"

/// Connecter des leds sur PE0 � PE7
/// Connecter un potentiometre sur ADC3 canal 7

/// Definir la routine d'interruption TIM2_Handler() dans le programme


void main()
    {
    /// configuration des ports
    LibGPIO_Conf(GPIOE, GPIO_Pin_Low, GPIO_Mode_OUT, GPIO_OType_PP, GPIO_Speed_2MHz);

    /// initialisation du Timer 2 et activation des interruptions
	/// valeurs a adapter
    LibTimer_Init(TIM2, 4000, 1000);
    LibTimer_Interrupts(TIM2, ENABLE);

    while(True)
        {
        /// les leds doivent clignoter grace au timer et interruptions
        }

	 Lib_delay(100000);
    }


/// routine d'interruption Timer 2
void TIM2_Handler()
{
    static int sel= 0;

    if (TIM_GetITStatus(TIM2, TIM_IT_Update) != RESET)		// verification interruption
    {
        if (sel)
            {
			GPIO_Write(GPIOE, 0);
            sel= 0;
            }
        else
            {			
			GPIO_Write(GPIOE, 0xFF);
            sel= 1;
            }

        TIM_ClearITPendingBit(TIM2, TIM_IT_Update);     // acquittement interruption
    }
}

