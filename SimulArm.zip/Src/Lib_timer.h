/**
 * Virtual Timer Library for STM32F4xx devices
 */

#include "Lib_32f4.h"

#include "Lib_interrupts.h"


#define	TIM_IT_Update	0
#define	MODE_CTC		1

// TIM2 et TIM5 sont des timers 32 bits
// TIM3 et TIM4 sont des timers 16 bits

extern TIM_TypeDef * TIM2;
extern TIM_TypeDef * TIM3;
extern TIM_TypeDef * TIM4;
extern TIM_TypeDef * TIM5;


/**
  * @brief  Configure Timer behaviour
  * @brief  TIM2 and TIM5 are 32 bits timers, TIM3 and TIM4 are 16 bits timers
  * @param  TIMx = TIM2 to TIM5
  * @param  prediv = timer prescaler
  * @param  period = timer periodicity
  * @retval None
  */
void LibTimer_Init(TIM_TypeDef * TIMx, uint16_t prediv, uint32_t period);

/**
  * @brief  Configure Timer interrupts
  * @brief  TIM2 and TIM5 are 32 bits timers, TIM3 and TIM4 are 16 bits timers
  * @param  TIMx = TIM2 to TIM5
  * @param  state = ENABLE or DISABLE
  * @retval None
  */
void LibTimer_Interrupts(TIM_TypeDef * TIMx, FunctionalState state);

/**
  * @brief  Checks whether the TIM interrupt has occurred or not.
  * @param  TIMx: where x can be 1 to 14 to select the TIM peripheral.
  * @param  TIM_IT: specifies the TIM interrupt source to check.
  * @retval The new state of the TIM_IT(SET or RESET).
  */
ITStatus TIM_GetITStatus(TIM_TypeDef* TIMx, uint16_t TIM_IT);

/**
  * @brief  Clears the TIMx's interrupt pending bits.
  * @param  TIMx: where x can be 1 to 14 to select the TIM peripheral.
  * @param  TIM_IT: specifies the pending bit to clear.
  * @retval None
  */
void TIM_ClearITPendingBit(TIM_TypeDef* TIMx, uint16_t TIM_IT);