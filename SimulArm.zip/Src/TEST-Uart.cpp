/************************************************************************************
 *
 * Test de l'UART 1 en utilisant le port COM1 du PC
 *
 ************************************************************************************/

/// Connecter l'UART a un autre PC ou un autre port COM local
/// Format = 8 bits, 1 stop, sans parite, 9600 bauds

/// Tester l'echo des caracteres

#include "Lib_32f4.h"

#include "Lib_gpio.h"
#include "Lib_uart.h"


void main()
    {
    uint8_t c;

	/// Initialize USART1 at 9600 bauds, 8, N, 1
	LibUart_Init(USART1, 9600, USART_WordLength_8b, USART_Parity_No, USART_StopBits_1);

    LibUart_Putc(USART1, '>');

	while(True)
        {
		// appel bloquant
		c= LibUart_Getc(USART1);

		// echo
		LibUart_Putc(USART1, c);
		if (c == '\r') LibUart_Putc(USART1, '\n');      // conversion sauts de lignes
        }
    }


