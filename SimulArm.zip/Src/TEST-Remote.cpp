/************************************************************************************
 *  File:     main.c
 *  Purpose:  Cortex-M4 main file.
 ************************************************************************************/

#include "Lib_32f4.h"

#include "Lib_Gpio.h"
#include "Lib_Remote.h"

/// Telecommande (Protocole NEC)

/// connecter l'afficheur 7 segments sur le Port G
/// connecter le r�cepteur infrarouge sur PD0

void main()
    {
    uint32_t key= 0;

    LibGPIO_Conf(GPIOD, GPIO_Pin_0 | GPIO_Pin_8, GPIO_Mode_IN, GPIO_PuPd_NOPULL, GPIO_Speed_2MHz);

	while(True)
        {
		key= Get_IRframe() ;	/// codes retournes par la telecommande (16 bits de poids faible)
		
		
		

        }
    }
