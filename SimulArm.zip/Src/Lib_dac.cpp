/**
 * Copyright (C) JG 2025
 */

#include "lib_dac.h"

static int DAC1_init= 0;
static int DAC2_init= 0;

static const uint16_t codes_dac[] = {0xF6, 0x90, 0x75, 0xF1, 0x93, 0xE3, 0xE7, 0xB0, 0xF7, 0xF3};

void LibDAC_Init(uint32_t DACx)
    {
	if (DACx == DAC1) 
		{
		DAC1_init= 1;

		/// initialisation du SPI1 en mode 8 bits avec predivision 256
		LibSPI_Init(SPI1, LibSPI_DataSize_8b, SPI_BaudRatePrescaler_256);
		}
	if (DACx == DAC2) 
		{
		DAC2_init= 1;

		/// initialisation du SPI2 en mode 8 bits avec predivision 256
		LibSPI_Init(SPI2, LibSPI_DataSize_8b, SPI_BaudRatePrescaler_256);
		}
    }

void LibDAC_Output(uint32_t DACx, uint16_t value)
    {
	if (value >= 4096) value= 4095;			// valeur maxi sur 12 bits

	int tension= (value * 3300) / 4095;

	int u= tension % 10;
    int d= (tension / 10) % 10;
    int c= (tension / 100) % 10;
    int m= tension / 1000;

	if ((DACx == DAC1) && (DAC1_init))
		{
		LibSPI_Send(SPI1, codes_dac[u]);
		LibSPI_Send(SPI1, codes_dac[d]);
		LibSPI_Send(SPI1, codes_dac[c]+0x08);		// affiche un point
		LibSPI_Send(SPI1, codes_dac[m]);
		}

	if ((DACx == DAC2) && (DAC2_init))
		{
		LibSPI_Send(SPI2, codes_dac[u]);
		LibSPI_Send(SPI2, codes_dac[d]);
		LibSPI_Send(SPI2, codes_dac[c]+0x08);		// affiche un point
		LibSPI_Send(SPI2, codes_dac[m]);
		}
    }
