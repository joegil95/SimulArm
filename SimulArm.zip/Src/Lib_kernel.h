
#include "Lib_32f4.h"

#include "Lib_timer.h"
#include "Lib_interrupts.h"

#include <string.h>

#define bool  	 char
#define false	 0
#define true	 1

#define NBT		 10   // nb maximal de taches y compris monitor
#define NBM		 10	  // nb maximal de messages
#define NBS		 10	  // nb maximal de semaphores

#define STOP	 0	  // status des taches
#define RUN		 1
#define SLEEP	 2

// messages
typedef struct TaskMsg
	{
	int pid1;  		  	// pid (n° de tache) emetteur
	int pid2;		  	// pid destinataire
	void * data;	  	// ptr sur donnees du msg
	unsigned size;  	// taille du msg en octets
	unsigned long time;	// horodatage du msg
	} TaskMsg;


// semaphores
typedef struct TaskSem
	{
	int pid;   		  	// pid createur
	char name[10];		// nom du semaphore
	int value;			// valeur du semaphore
	} Tasksem;


void Monitor(void);
void Task1(void);
void Task2(void);
void Task3(void);
void Task4(void);
void Task5(void);
void Task6(void);
void Task7(void);
void Task8(void);
void Task9(void);

void ConfigTasks();

void InitTasks(void);
void NextTask(void);
void TaskSleep(unsigned d);

bool SendMessage(int pidest, void * dat, unsigned s);
bool GetMessage(int pidorg, struct TaskMsg * msg);
bool CreateSemaphore(char * nom, int v);
bool ReadSemaphore(char * nom, int * val);
bool WriteSemaphore(char * nom, int val);
bool DeleteSemaphore(char * nom);