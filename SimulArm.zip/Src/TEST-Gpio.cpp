/************************************************************************************
 *  
 * Test Leds et boutons poussoirs
 *
 ************************************************************************************/

#include "Lib_32f4.h"

#include "Lib_gpio.h"
#include "Lib_binary.h"

/// Connecter 4 boutons sur PD0 � PD3
/// Connecter 4 leds sur PE0 � PE3


void main()
    {
    /// configuration des ports
    LibGPIO_Conf(GPIOD, GPIO_Pin_0 | GPIO_Pin_1 |  GPIO_Pin_2 | GPIO_Pin_3, GPIO_Mode_IN, GPIO_PuPd_UP, GPIO_Speed_2MHz);
    LibGPIO_Conf(GPIOE, GPIO_Pin_0 | GPIO_Pin_1 |  GPIO_Pin_2 | GPIO_Pin_3, GPIO_Mode_OUT, GPIO_OType_PP, GPIO_Speed_2MHz);

    while(True)
        {
		uint16_t x;
		
		/// recopie du port D sur le port E
		/// les boutons marchent en logique inverse a cause des pull-ups
        x= ~GPIO_ReadInputData(GPIOD);
        GPIO_Write(GPIOE, x);

		Lib_delay(1000);
        }
    }

