/**
 * I2C Library for STM32F4xx devices
 */

#ifndef I2C_H
#define I2C_H 161

#include "Lib_32f4.h"

#include "Lib_gpio.h"

/**
 *          PINS PACK 1   	PINS PACK 2   	PINS PACK 3
 * I2Cx     SCL   SDA    	SCL   SDA    	SCL   SDA
 *
 * I2C1     PB6   PB7    	PB8   PB9    	PB6   PB9
 * I2C2     PB10  PB11   	PF1   PF0    	PH4   PH5
 * I2C3     PA8   PC9    	PH7   PH8    	-     -
 */

extern I2C_TypeDef * I2C1;
extern I2C_TypeDef * I2C2;
extern I2C_TypeDef * I2C3;


#define LibI2C_SPEED_STND			100000      // I2C Standard speed 100 kHz
#define LibI2C_SPEED_FAST			400000      // I2C Fast speed 400 kHz
#define LibI2C_SPEED_FULL		    1000000     // I2C Full speed 1 MHz
#define LibI2C_SPEED_HIGH			3400000     // I2C High speed 3.4 MHz

#define I2C_STARTW				0x0100
#define I2C_STARTR				0x0200
#define I2C_STOP				0x0400
#define I2C_WRITE				0x1000
#define I2C_READN				0x2000
#define I2C_READL				0x4000
#define I2C_REG					0x8000

#define I2C_SEND				0
#define I2C_RECV				1

#define I2C_ACK_ENABLE			1
#define I2C_ACK_DISABLE			0


//  Public functions

void LibI2C_MasterInit(I2C_TypeDef* I2Cx, uint32_t clockSpeed);

int16_t LibI2C_GetReg(I2C_TypeDef* I2Cx, uint8_t address, uint8_t reg);
int16_t LibI2C_GetMultiReg(I2C_TypeDef* I2Cx, uint8_t address, uint8_t reg, uint8_t *data, uint16_t nb);
void LibI2C_SetReg(I2C_TypeDef* I2Cx, uint8_t address, uint8_t reg, uint8_t data);
void LibI2C_SetMultiReg(I2C_TypeDef* I2Cx, uint8_t address, uint8_t reg, uint8_t *data, uint16_t nb);

uint8_t DecToBcd(uint8_t c);
uint8_t BcdToDec(uint8_t c);

//  Private functions

int16_t LibI2C_Start(I2C_TypeDef* I2Cx, uint8_t address, uint8_t direction, uint8_t ack);
int16_t LibI2C_Stop(I2C_TypeDef* I2Cx);

int16_t LibI2C_ReadNext(I2C_TypeDef* I2Cx); // Will be followed by another LibI2C_ReadNext() or LibI2C_ReadLast()
int16_t LibI2C_ReadLast(I2C_TypeDef* I2Cx); // Will be followed by LibI2C_Stop()
void LibI2C_Write(I2C_TypeDef* I2Cx, uint8_t data);

#endif

