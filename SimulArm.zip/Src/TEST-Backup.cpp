/************************************************************************************
 *  File:     main.c
 *  Purpose:  Cortex-M4 main file.
 ************************************************************************************/

#include "Lib_32f4.h"

#include "Lib_gpio.h"
#include "Lib_backup.h"

#include "Lib_interrupts.h"

/// Connecter l'afficheur LCD sur le SPI2
/// Connecter le clavier matriciel sur PD8 � PD14


void main()
    {
    uint16_t x, y;

    /// initialisation Backup SRAM
    LibBackup_Init();

    /// ecriture de 4 octets en Backup SRAM
	LibBackup_Write8(0, 4);
    LibBackup_Write8(1, 3);
    LibBackup_Write8(2, 2);
    LibBackup_Write8(3, 1);

    while(True)
        {
		/// relecture sous forme de 2 mots
		x=LibBackup_Read16(0);
		y=LibBackup_Read16(2);

		Lib_delay(100000);
        }
    }

