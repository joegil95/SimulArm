/************************************************************************************
 *
 * Test du generateur de nombres aleatoires
 *
 ************************************************************************************/

#include "Lib_32f4.h"

#include "Lib_gpio.h"
#include "Lib_random.h"

/// Connecter des leds sur PD0 a PD15


void main()
    {
	uint32_t  r;

    /// configuration des ports
    LibGPIO_Conf(GPIOD, GPIO_Pin_All, GPIO_Mode_OUT, GPIO_OType_PP, GPIO_Speed_2MHz);

	/// initialisation du generateur
	LibRandom_Init();

    while(True)
        {
        r= LibRandom_Get();

		GPIO_Write(GPIOD, r & 0xFFFF);		// affichage 16 bits de poids faible

		Lib_delay(100000);
        }
    }

