/************************************************************************************
 *  File:     main.c
 *  Purpose:  Cortex-M4 main file.
 ************************************************************************************/


#include "Lib_32f4.h"

#include "Lib_gpio.h"
#include "Lib_spi.h"
#include "Lib_eeprom.h"

/// Connecter l'Eeprom AMD sur PD4-7 (Commandes) et PD8-15 (Data)
/// Connecter l'Eeprom sur le SPI2 aliment� en 5 V imp�rativement
/// Connecter des leds sur PE0-7

// Tableau des codes 7 segments 0 a F
const uint16_t codes_7_seg[]= {0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x6F,
	  	   					   0x77, 0x7C, 0x39, 0x5E, 0x79, 0x71};

uint8_t readdat[PAGESIZE];
uint8_t pagedat[PAGESIZE]= {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
							15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0};


void main(void)
	{
	uint8_t val= 0, x= 25;
    uint16_t adresse= 0x100;

    /// configuration des ports
    LibGPIO_Conf(GPIOE, GPIO_Pin_Low, GPIO_Mode_OUT, GPIO_OType_PP, GPIO_Speed_2MHz);

    /// initialisation de l'EEPROM et du SPI 2	
	LibEeprom_Init(GPIOD, SPI2);

	LibEeprom_Write(adresse, x);

	//	LibEeprom_PageWrite(0, pagedat);
	//	LibEeprom_PageRead(0, readdat);

	while(True)
	 	{
		val= LibEeprom_Read(adresse);

        GPIO_Write(GPIOE, val);

		Lib_delay(30000);
	 	}
	}

