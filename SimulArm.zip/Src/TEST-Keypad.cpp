/************************************************************************************
 *
 * Test du pave numerique (Keypad)
 *
 ************************************************************************************/

#include "Lib_32f4.h"

#include "Lib_gpio.h"
#include "Lib_keypad.h"



/// Connecter des leds sur PE0 à PE7
/// Connecter le clavier matriciel sur PD8 à PD14

/// envoie les touches du keypad en binaire sur les leds

void main()
    {
	 /// configuration des ports
	LibGPIO_Conf(GPIOE, GPIO_Pin_Low, GPIO_Mode_OUT, GPIO_OType_PP, GPIO_Speed_2MHz);

    /// initialisation ports clavier
    LibKeypad_Init(GPIOD, HIGH);

    while(true)
        {
        int8_t x= LibKeypad_Get(GPIOD);

        if (x != -1)
            {
            if ((x >= 0) && (x <= 9))
                {
                GPIO_Write(GPIOE, x);
                }

            if (x == 10)    // touche '*'
                {
		
                }

			if (x == 11)	// touche '#'
				{
				
				}
			}

		Lib_delay(200000);
        }
    }
