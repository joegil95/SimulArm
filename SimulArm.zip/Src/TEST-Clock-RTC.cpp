/************************************************************************************
 *
 * Test horloge RTC interne au �C
 *
 ************************************************************************************/

#include "Lib_32f4.h"

#include "Lib_gpio.h"
#include "Lib_clock.h"
#include "Lib_glcd.h"


/// connecter l'afficheur GLCD sur PF
/// Afficher le peripherique horloge RTC dans l'interface sinon ne peut pas fonctionner !!!


int main(void)
    {
    uint16_t x;
    uint8_t ha= 0, ma= 0, sa= 0;
    int choix= -1;

    RTC_DateTypeDef Clock_Date;
    RTC_TimeTypeDef Clock_Time;
    RTC_AlarmTypeDef Clock_Alarm;

    /// configuration horloge au format BCD
    Clock_Date.RTC_Year= 0;
    Clock_Date.RTC_Month= 0;
    Clock_Date.RTC_Date= 0;
    Clock_Date.RTC_WeekDay= 0;
	
    Clock_Time.RTC_Hours= 0;
    Clock_Time.RTC_Minutes= 0;
    Clock_Time.RTC_Seconds= 0;

    /// inutile de parametrer l'horloge en simulation car utilise l'horloge du PC
    LibClock_Init(CLOCK_SOURCE_LSE, &Clock_Date, &Clock_Time, CLOCK_CHECK);

    // initialisation afficheur GLCD
    GLCD_InitDisplay();
	GLCD_ClearScreen();

    while(True)
        {
        /// Exercice 1
        LibClock_GetTime(&Clock_Time);

        // Affichage heure sur GLCD � gauche au format HH:MM:SS
        GLCD_Move(0, 0, 0);
        if (Clock_Time.RTC_Hours < 10) GLCD_WriteChar('0');
        GLCD_ShowInt(BcdToDec(Clock_Time.RTC_Hours));
        GLCD_WriteChar(':');
        if (Clock_Time.RTC_Minutes < 10) GLCD_WriteChar('0');
        GLCD_ShowInt(BcdToDec(Clock_Time.RTC_Minutes));
        GLCD_WriteChar(':');
        if (Clock_Time.RTC_Seconds < 10) GLCD_WriteChar('0');
        GLCD_ShowInt(BcdToDec(Clock_Time.RTC_Seconds));

        // Affichage date sur GLCD � gauche au format JJ/MM/AA
		LibClock_GetDate(&Clock_Date);
        GLCD_Move(0, 2, 0);
        if (Clock_Date.RTC_Date < 10) GLCD_WriteChar('0');
		GLCD_ShowInt(BcdToDec(Clock_Date.RTC_Date));
        GLCD_WriteChar('/');
        if (Clock_Date.RTC_Month < 10) GLCD_WriteChar('0');
		GLCD_ShowInt(BcdToDec(Clock_Date.RTC_Month));
        GLCD_WriteChar('/');
        if (Clock_Date.RTC_Year < 10) GLCD_WriteChar('0');
		GLCD_ShowInt(BcdToDec(Clock_Date.RTC_Year));

        Lib_delay(100000);
        }
    }

