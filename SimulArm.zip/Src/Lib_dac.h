/**
 * DAC Library for STM32F4xx devices
 */


#ifndef LibDAC_H
#define libDAC_H 110

#include "Lib_32f4.h"

#include "Lib_spi.h"

//  This library provides 12-bit analog output values from 0 to 4095 = 0 to 3,3 V
//	Values are displayed on LCD 4-digit display using SPI1 for DAC1 and SPI2 for DAC2

#define	DAC1	1		// DAC channel 1
#define DAC2	2		// DAC channel 2

/**
 * @brief  Initialize DAC channel and pin
 * @param  DACx = DAC1 or DAC2
 * @retval None
 */
void LibDAC_Init(uint32_t DACx);

/**
 * @brief  Output analog voltage to ADCx
 * @param  DACx = DAC1 or DAC2
 * @param  value = 12-bit unsigned value from 0 to 4095
 * @retval None
 */
void LibDAC_Output(uint32_t DACx, uint16_t value);

#endif
