#ifndef __STM32F4xx_H
#define __STM32F4xx_H

#include <stdio.h>


#define	DISABLE	0
#define	ENABLE	1
#define RESET	2

typedef unsigned char uint8_t;

typedef unsigned short uint16_t;
typedef unsigned int uint32_t;
typedef unsigned long long uint64_t;

typedef signed char int8_t;
typedef signed short int16_t;
typedef int int32_t;
typedef long long int64_t;

typedef int	FunctionalState;
typedef int	ITStatus;

typedef void * HANDLE;

extern int True;


typedef struct
	{
	int Port_num;
	} 
GPIO_TypeDef;


typedef struct
	{
	GPIO_TypeDef * AdcPort;
	char resol[16];				// resolution ADC
	}
ADC_TypeDef;


typedef struct
	{
	GPIO_TypeDef * SpiPort;
	uint16_t Datasize;
	uint16_t Prescaler;
	}
SPI_TypeDef;


typedef struct
	{
	uint8_t Enabled;
	uint32_t Speed;
	}
I2C_TypeDef;


typedef struct
	{
	uint16_t Id;			// Timer N�
	uint16_t Prescaler;
	uint32_t Period;
	uint16_t Mode;
	uint32_t Count;
	uint16_t Interrupt;
	uint16_t Pending;
	} 
TIM_TypeDef;

#define EXTI_Line0       ((uint32_t)0x00001)     /*!< External interrupt line 0 */
#define EXTI_Line1       ((uint32_t)0x00002)     /*!< External interrupt line 1 */
#define EXTI_Line2       ((uint32_t)0x00004)     /*!< External interrupt line 2 */
#define EXTI_Line3       ((uint32_t)0x00008)     /*!< External interrupt line 3 */
#define EXTI_Line4       ((uint32_t)0x00010)     /*!< External interrupt line 4 */
#define EXTI_Line5       ((uint32_t)0x00020)     /*!< External interrupt line 5 */
#define EXTI_Line6       ((uint32_t)0x00040)     /*!< External interrupt line 6 */
#define EXTI_Line7       ((uint32_t)0x00080)     /*!< External interrupt line 7 */
#define EXTI_Line8       ((uint32_t)0x00100)     /*!< External interrupt line 8 */
#define EXTI_Line9       ((uint32_t)0x00200)     /*!< External interrupt line 9 */
#define EXTI_Line10      ((uint32_t)0x00400)     /*!< External interrupt line 10 */
#define EXTI_Line11      ((uint32_t)0x00800)     /*!< External interrupt line 11 */
#define EXTI_Line12      ((uint32_t)0x01000)     /*!< External interrupt line 12 */
#define EXTI_Line13      ((uint32_t)0x02000)     /*!< External interrupt line 13 */
#define EXTI_Line14      ((uint32_t)0x04000)     /*!< External interrupt line 14 */
#define EXTI_Line15      ((uint32_t)0x08000)     /*!< External interrupt line 15 */
#define EXTI_Line16      ((uint32_t)0x10000)     /*!< External interrupt line 16 */
#define EXTI_Line17      ((uint32_t)0x20000)     /*!< External interrupt line 17 */
#define EXTI_Line18      ((uint32_t)0x40000)     /*!< External interrupt line 18 */                                    
#define EXTI_Line19      ((uint32_t)0x80000)     /*!< External interrupt line 19 */
#define EXTI_Line20      ((uint32_t)0x00100000)  /*!< External interrupt line 20 */
#define EXTI_Line21      ((uint32_t)0x00200000)  /*!< External interrupt line 21 */                                               
#define EXTI_Line22      ((uint32_t)0x00400000)  /*!< External interrupt line 22 */                                               

typedef struct
	{
	uint32_t EXTI_Lines;				// Specifies enabled EXTI lines
	uint32_t Pending;					// Specifies pending states
	}
EXTI_InitTypeDef;


typedef struct
	{
	uint8_t RTC_WeekDay;	// RTC Date WeekDay in 1-7 range
	uint8_t RTC_Month;		// RTC Date Month in 1-12 range
	uint8_t RTC_Date;		// RTC Date Day in 1-31 range
	uint8_t RTC_Year;		// RTC Date Year in 0-99 range
	}
RTC_DateTypeDef;

typedef struct
	{
	uint8_t RTC_Hours;		// RTC Time Hour in 0-12 range or 0-23 range 
	uint8_t RTC_Minutes;	// RTC Time Minutes in 0-59 range
	uint8_t RTC_Seconds;	// RTC Time Seconds in 0-59 range
	uint8_t RTC_H12;		// RTC Time Hour format 0-12 or 0-24
	}
RTC_TimeTypeDef;

typedef struct
	{	
	RTC_TimeTypeDef RTC_AlarmTime;		// RTC Alarm Time members
	uint32_t RTC_AlarmMask;				// RTC Alarm Masks
	uint32_t RTC_AlarmDateWeekDaySel;	// RTC Alarm is on Date or WeekDay 
	uint8_t RTC_AlarmDateWeekDay;		// Specifies the RTC Alarm Date or WeekDay
	}
RTC_AlarmTypeDef;

typedef struct
	{
	uint8_t Enabled;
	RTC_DateTypeDef Date;
	RTC_TimeTypeDef Time;
	uint8_t AlarmAEnabled;
	uint8_t AlarmBEnabled;
	uint8_t AlarmAOn;
	uint8_t AlarmBOn;
	RTC_AlarmTypeDef AlarmA;
	RTC_AlarmTypeDef AlarmB;
	}
RTC_TypeDef;

typedef struct
	{
	uint16_t USART_Id;					// USART number
	HANDLE USART_Hd;					// USART Port Handle
	uint32_t USART_BaudRate;            // USART communication baud rate.                                          
	uint16_t USART_WordLength;          // Specifies the number of data bits transmitted or received in a frame.
	uint16_t USART_StopBits;            // Specifies the number of stop bits transmitted.                                           
	uint16_t USART_Parity;              // Specifies the parity mode.
	uint16_t USART_Mode;                // Specifies wether the Receive or Transmit mode is enabled or disabled.
	} 
USART_TypeDef;

typedef struct
	{
	uint8_t Enabled;
	void * CardInfo;				// pointeur sur SD_CardInfo
	} 
SDIO_TypeDef;


void SystemInit(void);

#endif /* __STM32F4xx_H */

