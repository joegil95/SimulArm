/**
 * Virtual SPI library for STM32F4xx
 */

#ifndef LibSPI_H
#define LibSPI_H 200

#include "Lib_32f4.h"


extern SPI_TypeDef * SPI1;
extern SPI_TypeDef * SPI2;
extern SPI_TypeDef * SPI3;

#define	LibSPI_DataSize_8b		8
#define	LibSPI_DataSize_16b		16

#define SPI_BaudRatePrescaler_2		2
#define SPI_BaudRatePrescaler_4     4
#define SPI_BaudRatePrescaler_8     8
#define SPI_BaudRatePrescaler_16    16
#define SPI_BaudRatePrescaler_32    32
#define SPI_BaudRatePrescaler_64    64
#define SPI_BaudRatePrescaler_128   128
#define SPI_BaudRatePrescaler_256   256

typedef uint16_t	LibSPI_DataSize_t;

/**
 * @brief  Initializes SPIx peripheral with custom pinspack and default other settings
 * @param  *SPIx: Pointer to SPIx peripheral you will use, where x is between 1 to 6
 * @param  SPI_DataSize: SPI data size LibSPI_DataSize_8b or LibSPI_DataSize_16b
 * @param  SPI_BaudRatePrescaler: SPI prescaler SPI_BaudRatePrescaler_2 to SPI_BaudRatePrescaler_256
 * @retval None
 */
void LibSPI_Init(SPI_TypeDef* SPIx, LibSPI_DataSize_t SPI_DataSize, uint16_t SPI_BaudRatePrescaler);


/**
 * @brief  Sends and receives single byte over SPI
 * @param  *SPIx: Pointer to SPIx peripheral you will use, where x is between 1 to 6
 * @param  data: 8-bit data size to send over SPI
 * @retval Received byte from slave device
 */
uint16_t LibSPI_Send(SPI_TypeDef* SPIx, uint16_t data);

#endif

