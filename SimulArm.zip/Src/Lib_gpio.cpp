/**
 * Copyright (C) JG 2020
 */

#include "Lib_gpio.h"

#include "SimulArm.h"

extern Stm32F407 MyStm;

GPIO_TypeDef GPIOa= {0};
GPIO_TypeDef GPIOb= {1};
GPIO_TypeDef GPIOc= {2};
GPIO_TypeDef GPIOd= {3};
GPIO_TypeDef GPIOe= {4};
GPIO_TypeDef GPIOf= {5};
GPIO_TypeDef GPIOg= {6};

GPIO_TypeDef * GPIOA= &GPIOa;
GPIO_TypeDef * GPIOB= &GPIOb;
GPIO_TypeDef * GPIOC= &GPIOc;
GPIO_TypeDef * GPIOD= &GPIOd;
GPIO_TypeDef * GPIOE= &GPIOe;
GPIO_TypeDef * GPIOF= &GPIOf;
GPIO_TypeDef * GPIOG= &GPIOg;

// a laisser ici pour bonne compilation
ADC_TypeDef Adc1= {GPIOA, {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}};
ADC_TypeDef Adc2= {GPIOB, {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}};		// en realite sur GPIOA
ADC_TypeDef Adc3= {GPIOF, {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}};

ADC_TypeDef * ADC1= &Adc1;
ADC_TypeDef * ADC2= &Adc2;
ADC_TypeDef * ADC3= &Adc3;


// a laisser ici pour bonne compilation
SPI_TypeDef SDio= {GPIOA, 0, 0};				// En fait port SDIO pour SD Card
SPI_TypeDef Spi1= {GPIOA, 0, 0};
SPI_TypeDef Spi2= {GPIOC, 0, 0};
SPI_TypeDef Spi3= {GPIOB, 0, 0};

SPI_TypeDef * SDIO= &SDio;
SPI_TypeDef * SPI1= &Spi1;
SPI_TypeDef * SPI2= &Spi2;
SPI_TypeDef * SPI3= &Spi3;


I2C_TypeDef I2c1= {0, 0};
I2C_TypeDef I2c2= {0, 0};
I2C_TypeDef I2c3= {0, 0};

I2C_TypeDef * I2C1= &I2c1;
I2C_TypeDef * I2C2= &I2c2;
I2C_TypeDef * I2C3= &I2c3;


TIM_TypeDef Tim2= {2, 0, 0, 0, 0, 0, 0};
TIM_TypeDef Tim3= {3, 0, 0, 0, 0, 0, 0};
TIM_TypeDef Tim4= {4, 0, 0, 0, 0, 0, 0};
TIM_TypeDef Tim5= {5, 0, 0, 0, 0, 0, 0};

TIM_TypeDef * TIM2= &Tim2;
TIM_TypeDef * TIM3= &Tim3;
TIM_TypeDef * TIM4= &Tim4;
TIM_TypeDef * TIM5= &Tim5;

EXTI_InitTypeDef Exti= {0, 0};
EXTI_InitTypeDef * EXTI= &Exti;

USART_TypeDef Usart1= {0, 0, 0, 0, 0, 0};
USART_TypeDef Usart2= {0, 0, 0, 0, 0, 0};
USART_TypeDef Usart3= {0, 0, 0, 0, 0, 0};
USART_TypeDef Uart4= {0, 0, 0, 0, 0, 0};
USART_TypeDef Uart5= {0, 0, 0, 0, 0, 0};
USART_TypeDef Usart6= {0, 0, 0, 0, 0, 0};

USART_TypeDef * USART1= &Usart1;
USART_TypeDef * USART2= &Usart2;
USART_TypeDef * USART3= &Usart3;
USART_TypeDef * UART4= &Uart4;
USART_TypeDef * UART5= &Uart5;
USART_TypeDef * USART6= &Usart6;

SDIO_TypeDef SDcard= {0, NULL};

SDIO_TypeDef * SDCARD= &SDcard;


void SystemInit (void)
	{
	}


void Lib_delay(long d)
	{
	for (long t= 0 ; t < (d*1000) ; t++);
	}


void LibGPIO_Conf(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin, LibGPIO_Mode_t GPIO_Mode,
    LibGPIO_OType_t GPIO_Type, LibGPIO_Speed_t GPIO_Speed)
    {
    for (int p= 0 ; p < 7 ; p++)
		if (GPIOx->Port_num == p)
		{
			if (GPIO_Mode == GPIO_Mode_IN)
			    {
				for (int i= 0 ; i < 16 ; i++)
					{
					/*
					if ((p == 3) && (i == 2))		// Pd2 non utilisable
						{
						MyStm.Ports[p].setMode(i, STPORT_INP);
						MyStm.Ports[p].setPull(i, STPORT_PNO);
						MyStm.Ports[p].setInput(i, 0);
						continue;
						}
					*/

					if (GPIO_Pin & (1 << i))		// pin i sur port p = entree
						{
						MyStm.Ports[p].setMode(i, STPORT_INP);			
						if (GPIO_Type == GPIO_PuPd_NOPULL)
							{
							MyStm.Ports[p].setPull(i, STPORT_PNO);		// entree sans tirage
							MyStm.Ports[p].setInput(i, rand() & 1);		// etat aleatoire
							}
						if (GPIO_Type == GPIO_PuPd_UP)
							{
							MyStm.Ports[p].setPull(i, STPORT_PUP);		// entree avec tirage haut
							MyStm.Ports[p].setInput(i, 1);				// etat 1
							}
						if (GPIO_Type == GPIO_PuPd_DOWN)
							{
							MyStm.Ports[p].setPull(i, STPORT_PDN);		// entree avec tirage bas
							MyStm.Ports[p].setInput(i, 0);				// etat 0
							}
						}
					}
				}

			if (GPIO_Mode == GPIO_Mode_OUT)
			    {
				for (int i= 0 ; i < 16 ; i++)
					{
					/*
					if ((p == 3) && (i == 2))		// Pd2 non utilisable
						{
						MyStm.Ports[p].setMode(i, STPORT_INP);
						continue;
						}
					*/

					if (GPIO_Pin & (1 << i))
						{
						MyStm.Ports[p].setMode(i, STPORT_OUT);			// pin i sur port p = sortie					
						}
					}
				}
		}
	}


uint16_t GPIO_ReadInputData(GPIO_TypeDef* GPIOx)
	{
	uint16_t res= 0;

	for (int8_t i= 0 ; i < 16 ; i++)
		{
		/*
		if ((GPIOx->Port_num == 3) && (i == 2)) continue;				// Pd2 inutilisable => ignore
		*/
		
		res |= (MyStm.Ports[GPIOx->Port_num].getInput(i) << i);
		}
	
	return res;
	}


void GPIO_Write(GPIO_TypeDef * GPIOx, uint16_t PortVal)
	{
	for (int8_t i= 0 ; i < 16 ; i++)
		{
		/*
		if ((GPIOx->Port_num == 3) && (i == 2)) continue;				// Pd2 inutilisable => ignore
		*/

		MyStm.Ports[GPIOx->Port_num].setOutput(i, (PortVal >> i) & 1);
		}
	MyStm.Update(GPIOx);	
	}

void GPIO_WriteLow(GPIO_TypeDef * GPIOx, uint8_t LowVal)
	{
	for (int8_t i= 0 ; i < 8 ; i++)
		{
		/*
		if ((GPIOx->Port_num == 3) && (i == 2)) continue;				// Pd2 inutilisable => ignore
		*/

		MyStm.Ports[GPIOx->Port_num].setOutput(i, (LowVal >> i) & 1);
		}
	MyStm.Update(GPIOx);	
	}

void GPIO_WriteHigh(GPIO_TypeDef * GPIOx, uint8_t HigVal)
	{
	for (int8_t i= 0 ; i < 8 ; i++)
		{
		MyStm.Ports[GPIOx->Port_num].setOutput(i+8, (HigVal >> i) & 1);
		}
	MyStm.Update(GPIOx);	
	}

void GPIO_SetBits(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin)
	{
	for (int8_t i= 0 ; i < 16 ; i++)
		{
		/*
		if ((GPIOx->Port_num == 3) && (i == 2)) continue;				// Pd2 inutilisable => ignore
		*/

		if (GPIO_Pin & (1 << i))
			MyStm.Ports[GPIOx->Port_num].setOutput(i, 1);
		}
	MyStm.Update(GPIOx);
	}

void GPIO_ResetBits(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin)
	{
	for (int i= 0 ; i < 16 ; i++)
		{
		/*
		if ((GPIOx->Port_num == 3) && (i == 2)) continue;				// Pd2 inutilisable => ignore
		*/

		if (GPIO_Pin & (1 << i))
			MyStm.Ports[GPIOx->Port_num].setOutput(i, 0);
		}
	MyStm.Update(GPIOx);
	}

uint8_t GPIO_ReadInputDataBit(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin)
	{
	/*
	if ((GPIOx->Port_num == 3) && (GPIO_Pin == GPIO_Pin_2)) return 0;			// Pd2 inutilisable => ignore	
	*/

	for (int8_t i= 0 ; i < 16 ; i++)
		{
		if (GPIO_Pin & (1 << i))
			{
			if (MyStm.Ports[GPIOx->Port_num].getInput(i)) return 1;
			else return 0;
			}
		}
	}

uint8_t GPIO_ReadOutputDataBit(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin)
	{
	/*
	if ((GPIOx->Port_num == 3) && (GPIO_Pin == GPIO_Pin_2)) return 0;			// Pd2 inutilisable => ignore	
	*/

	for (int8_t i= 0 ; i < 16 ; i++)
		{
		if (GPIO_Pin & (1 << i))
			{
			if (MyStm.Ports[GPIOx->Port_num].getOutput(i)) return 1;
			else return 0;
			}
		}
	}